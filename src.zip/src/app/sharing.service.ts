import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SharingService {
  uname: any;
  passw:any;
  tokendata: any;   
  usercredential: { 'UserName': any; 'Password': any; };
  username: string;
  password: string;

  constructor(public http: HttpClient) { }
 
  tokenGet(credential: object) {
    // console.log('wasdsadsadasdasdsad');
    // console.log(credential);
    return this.http.post<any>(environment.baseUrl +"/Api/Auth/Authenticate", credential)
        .pipe(map(user => {
            // login successful if there's a jwt token in the response
            if (user && user.tokenString) {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('applicationUser', JSON.stringify(user));
            }
            return user;  
        }));
}

  // public TokenGet() {
  //   this.uname = localStorage.getItem('currentUser');
  //   this.passw = localStorage.getItem('currentPassword');
  //   console.log(this.uname);
  //   console.log(this.passw);

  //  this.usercredential= {
  //   'UserName':this.uname,
  //   'Password':this.passw
  //     }
  //   // if (localStorage.getItem('currentUser') == null) {
  //   //   this.router.naviga.te(['/']);
  //   // }


  //   this.http.post(environment.baseUrl +"/Api/Auth/Authenticate", this.usercredential).subscribe((res: Response) => {
  //     return  res["tokenString"];
  //   },
  //     error => {
  //       console.log('ERROR');
  //     });
  // }

  // public MakeAuditLog(auditlog) {
  //   this.http.post(environment.baseUrl + "/postdata/_doc/auditlog", auditlog).subscribe((res: Response) => {
  //   });
  // }
 
  // public guid() {
  //   function s4() {
  //     return Math.floor((1 + Math.random()) * 0x10000)
  //       .toString(16)
  //       .substring(1);
  //   }
  //   return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
  // }
}