import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-add-time-rule',
  templateUrl: './add-time-rule.component.html',
  styleUrls: ['./add-time-rule.component.css']
})
export class AddTimeRuleComponent implements OnInit {
  addtimeruleModel: any;
  addtimeruleform: FormGroup;
  submitted: false;
  LateExemption: boolean;
  sortleave: boolean;
  extraworking: boolean;
  extraworkWeekoff: boolean;
  constraint: boolean;
  lunchtimefn: boolean;
  selectedvalue: any;
  selectedtype: any;
  ShowFilter = false;
  limitSelection = false;
  exitimediv: boolean;
  LateExemptionafter: boolean;
  weekoffdays: any[] = [];
  dropdownSettings: any = {};
  selectedItems: any[] = [];
  constructor(private http: HttpClient, public formBuilder: FormBuilder) { }

  ngOnInit() {
    this.addtimeruleform = this.formBuilder.group({
      timeruletitle: ['', Validators.required],
      ApplicableTimeZone: ['', Validators.required],
      MorningPunchfrom: ['', Validators.required],
      MorningPunchto: ['', Validators.required],
      EntryRelaxation: ['', Validators.required],
      RelaxationOn: ['', Validators.required],
      RelaxationOnNo: ['', Validators.required],
      AfternoonEntryFrom: ['', Validators.required],
      AfternoonEntryTo: ['', Validators.required],
      AfternoonRelaxation: ['', Validators.required],
      AfternoonRelaxationOn: ['', Validators.required],
      AfternoonRelaxationNo: ['', Validators.required],
      fulldayhours: ['', Validators.required],
      HalfDayHours: ['', Validators.required],
      exitTime: ['', Validators.required],
      LunchTimeApplicable: ['', Validators.required],
      LunchTimeFrom: ['', Validators.required],
      LunchTimeTo: ['', Validators.required],
      shortleave: ['', Validators.required],
      AfterWorkingHour: ['', Validators.required],
      shortleaveNo: ['', Validators.required],
      MaxOvertime: ['', Validators.required],
      Paidoff: ['', Validators.required],
      Weeklyoffdays: ['', Validators.required],
      Weeklyoffdaystype: ['', Validators.required],
      weekoffdaysform: ['', Validators.required],
      Constraint: ['', Validators.required],
      ConstraintIntime: ['', Validators.required],
      ConstraintOuttime: ['', Validators.required],
      Constrainthalfday: ['', Validators.required],
      Constraintfullday: ['', Validators.required]
    });
    this.weekoffdays = [
      { day_id: 1, day_text: 'All' },
      { day_id: 2, day_text: '1st' },
      { day_id: 3, day_text: '2nd' },
      { day_id: 4, day_text: '3rd' },
      { day_id: 5, day_text: '4th' },
      { day_id: 6, day_text: '5th' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'day_id',
      textField: 'day_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: this.ShowFilter
    };
    this.addtimeruleform = this.formBuilder.group({
      Days: [this.selectedItems]
    });
    this.LateExemption = false;
    this.LateExemptionafter = false;
    this.sortleave = true;
    this.extraworking = true;
    this.extraworkWeekoff = true;
    this.constraint = true;
    this.lunchtimefn = true;
    this.constraint = false;
    this.exitimediv = true;
  }
  onSubmit() {
    this.addtimeruleModel = {
      "title": this.addtimeruleform.value.timeruletitle,
      "timeZoneId": this.addtimeruleform.value.ApplicableTimeZone,
      "inTimeFrom ": this.addtimeruleform.value.MorningPunchfrom,
      "inTimeOut  ": this.addtimeruleform.value.MorningPunchto,
      "inTimeRelaxation": this.addtimeruleform.value.EntryRelaxation,
      "inTimeRelaxationDur": this.addtimeruleform.value.RelaxationOn,
      "inTimeRelaxationDays": this.addtimeruleform.value.RelaxationOnNo,
      "noonInTimeFrom": this.addtimeruleform.value.AfternoonEntryFrom,
      "noonInTimeTo": this.addtimeruleform.value.AfternoonEntryTo,
      "noonInTimeRelaxation": this.addtimeruleform.value.AfternoonRelaxation,
      "noonInTimeRelaxationDur": this.addtimeruleform.value.AfternoonRelaxationOn,
      "noonInTimeRelaxationDays": this.addtimeruleform.value.AfternoonRelaxationNo,
      "fullDayMinute": this.addtimeruleform.value.fulldayhours,
      "halfDayMinute": this.addtimeruleform.value.HalfDayHours,
      "exitTime": this.addtimeruleform.value.exitTime,
      "isLunchTimeApp": this.addtimeruleform.value.LunchTimeApplicable,
      "lunchInTimeFrom": this.addtimeruleform.value.LunchTimeFrom,
      "lunchOutTimeFrom ": this.addtimeruleform.value.LunchTimeTo,
      "shortLeaveDur": this.addtimeruleform.value.shortleave,
      "shortLeaveAllowedAfterMinute": this.addtimeruleform.value.AfterWorkingHour,
      "shortLeaveAllowedDays": this.addtimeruleform.value.shortleaveNo,
      "maxOvertimeAllowedMinute ": this.addtimeruleform.value.MaxOvertime,
      "overtimePaidOffOrLeave": this.addtimeruleform.value.Paidoff,
      "isConstAppForWOorHOvertime ": this.addtimeruleform.value.Constraint,
      "inTimeForWOorH": this.addtimeruleform.value.ConstraintIntime,
      "outTimeForWOorH": this.addtimeruleform.value.ConstraintOuttime,
      "halfdayMinuteForWOorH": this.addtimeruleform.value.Constrainthalfday,
      "fulldayMinuteForWOorH": this.addtimeruleform.value.Constraintfullday,
      "isOvertimeApp": ''
    };
    //this.submitted = true
    // stop here if form is invalid
    if (!this.addtimeruleform.valid) {
      return false;
    } else if (this.addtimeruleform.valid) {
      this.http.post(environment.baseUrl + '/api/Time/InsertUpdateTimeRule', this.addtimeruleModel).subscribe((res: Response) => {
        console.log(res);
      }, error => console.error(error));
    }
  }
  onItemSelect(item: any) {
    console.log('onItemSelect', item);
  }
  onSelectAll(items: any) {
    console.log('onSelectAll', items);
  }
  toogleShowFilter() {
    this.ShowFilter = !this.ShowFilter;
    this.dropdownSettings = Object.assign({}, this.dropdownSettings, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
    if (this.limitSelection) {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
    } else {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
    }
  }

  latexemradio(e: string): void {
    if (e === "yes") {
      this.LateExemption = true;
    }
    else
      this.LateExemption = false;
  }
  latexemafterradio(e: string): void {
    if (e === "yes") {
      this.LateExemptionafter = true;
    }
    else
      this.LateExemptionafter = false;
  }
  sortleaveradio(e: string): void {
    if (e === "yes") {
      this.sortleave = true;
    }
    else
      this.sortleave = false;
  }
  extraworkradio(e: string): void {
    if (e === "yes") {
      this.extraworking = true;
    }
    else
      this.extraworking = false;
  }
  extraweekoffradio(e: string): void {
    if (e === "yes") {
      this.extraworkWeekoff = true;
    }
    else {
      this.extraworkWeekoff = false;
      this.constraint = false;
    }
  }
  lunchtime(event: any) {
    if (event.target.value === 'yes') {
      this.lunchtimefn = true;
    }
    else
      this.lunchtimefn = false;
    // this.selectedtype = event.target.value;
    // var a = this.selectedtype;
  }
  constraintselect(event: any) {
    if (event.target.value == 'Constraint') {
      this.constraint = true;
    }
    else
      this.constraint = false;
  }
  exitimeradio(e: string): void {
    if (e === 'yes') {
      this.exitimediv = true;
    }
    else
      this.exitimediv = false;
  }
}

