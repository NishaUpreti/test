import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTimeRuleComponent } from './add-time-rule.component';

describe('AddTimeRuleComponent', () => {
  let component: AddTimeRuleComponent;
  let fixture: ComponentFixture<AddTimeRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddTimeRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTimeRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
