import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRemarksInnerComponent } from './add-remarks-inner.component';

describe('AddRemarksInnerComponent', () => {
  let component: AddRemarksInnerComponent;
  let fixture: ComponentFixture<AddRemarksInnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddRemarksInnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddRemarksInnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
