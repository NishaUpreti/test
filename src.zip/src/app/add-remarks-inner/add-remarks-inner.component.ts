import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-remarks-inner',
  templateUrl: './add-remarks-inner.component.html',
  styleUrls: ['./add-remarks-inner.component.css']
})
export class AddRemarksInnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
