import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasicEmpComponent } from './basic-emp.component';

describe('BasicEmpComponent', () => {
  let component: BasicEmpComponent;
  let fixture: ComponentFixture<BasicEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasicEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasicEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
