import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { BasicInfoModel } from '../model/basic-emp-model'
declare function datetimeFunc(): any;
declare function select2Func(): any;
@Component({
  selector: 'app-basic-emp',
  templateUrl: './basic-emp.component.html',
  styleUrls: ['./basic-emp.component.css']
})
export class BasicEmpComponent implements OnInit {  
  basicinfo_form: FormGroup;
  private BasicInfoModel: BasicInfoModel;
  submitted = false;
  display = 'none';
  authtoken: void;
  uname: string;
  passw: string;
  basicmodal: any;
  usercredential: { 'UserName': string; 'Password': string; };
  designationdata: any;
  tokenData: any;
  GetTokens: void;
  departmentdata: any;
  orgnisationdata: any;
  empcountry: any;
  empstate: any;
  empcity: any;
  countryIdchnge: any;
  statewisecountry: any;
  stateIdchnge: any;
  citywisecountry: any;
  eventIdchnge: any;
  departmentID: any;
  division: any;
  rolelist: any;
  emplist: any;
  emptypelist: any;
  empstatuslist: any;
  Date: string;
  Datelogs: string;
  orgIdchnge: any;
  branchlocation: any;
  isLinear = false;
  firstFormGroup: FormGroup;
  checkbox: boolean;
  selectedStatus: any;
  permanent_houseno:any;
  empcountrires: Object;
  statewisecountryies: Object;
  citywisecountryies: Object;
  joineddate:any;
  joiningDate: string | number | string[];
  dateBirth: string | number | string[];
  perhouseno: any;
  perhousename: any;
  perstreet: any;
  percountry: any;
  perstate: any;
  percity: any;
  perpin: any;
  biometricids: any;

  constructor(private http: HttpClient, public SharingService: SharingService, public _formBuilder: FormBuilder) { }

  ngOnInit() {

    this.Date = formatDate(new Date(), 'mm-dd-yyyy', 'en');
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.basicinfo_form = this._formBuilder.group({
      userName: ['', Validators.required],
      punchid: ['', Validators.required],
      emailid: ['', [Validators.required, Validators.email]],
      firstname: ['', Validators.required],
    //  workingemail: ['', [Validators.required, Validators.email]],
      empid: ['', Validators.required],
      joiningdate: [''],
      company: ['', Validators.required],
      branchlocation: ['', Validators.required],
      department: [''],
      division: [''],
      designation: [''],
      empstatus: [''],
     // emptype: [''],
      houseno: ['', Validators.required],
      housename: ['', Validators.required],
      road: ['', Validators.required],
      country: ['', Validators.required],
      state: ['',Validators.required],
      city: ['',Validators.required],
      permanent_houseno: ['',Validators.required],
      permanent_housename: ['',Validators.required],
      permanent_road: ['',Validators.required],
      permanentAddressCountry: ['',Validators.required],
      permanentAddressState: ['',Validators.required],
      permanentAddressCity: ['',Validators.required],
      permanent_pincode:['',Validators.required],
      assignedrole: [''],
      reportingto: [''],
      middleName: [],
      lastName: [''],
      DOB: [''], officialMobileNo: [''], gender: [''], type: [''],
      extentionNumber: [''], pincode: ['',Validators.required ]
    });
    this.http.get(environment.baseUrl + '/Api/Master/GetDesignationList').subscribe(result => {
      this.designationdata = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/Api/Master/GetDepartmentList').subscribe(result => {
      this.departmentdata = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/Api/Master/GetOrganizationList').subscribe(result => {
      this.orgnisationdata = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/Api/Master/GetCountryList').subscribe(result => {
      this.empcountry = result;
      this.empcountrires = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/api/Master/GetAccessRoleList').subscribe(result => {
      this.rolelist = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/api/Master/GetEmployeeNameAndIdList').subscribe(result => {
      this.emplist = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/api/Master/GetEmploymentTypeList').subscribe(result => {
      this.emptypelist = result;
    }, error => console.error(error));
    this.http.get(environment.baseUrl + '/api/Master/GetEmployeeStatusList').subscribe(result => {
      this.empstatuslist = result;
    }, error => console.error(error));
  }
  selectchangecountry(event) {
    this.countryIdchnge = event.target.value;
    this.http.get(environment.baseUrl + '/Api/Master/GetStateList?CountryId=' + this.countryIdchnge).subscribe(result => {
      this.statewisecountry = result;
    }, error => console.error(error));
  }

  selectchangecountryies(event) {
    this.countryIdchnge = event.target.value;
    this.http.get(environment.baseUrl + '/Api/Master/GetStateList?CountryId=' + this.countryIdchnge).subscribe(result => {
      this.statewisecountryies = result;
    }, error => console.error(error));
  }

  selectchangestate(eventstate) {
    this.stateIdchnge = eventstate.target.value;
    this.http.get(environment.baseUrl + '/Api/Master/GetCityList?StateId=' + this.stateIdchnge).subscribe(result => {
      this.citywisecountry = result;
    }, error => console.error(error));
  }

  selectchangestates(eventstate) {
    this.stateIdchnge = eventstate.target.value;
    this.http.get(environment.baseUrl + '/Api/Master/GetCityList?StateId=' + this.stateIdchnge).subscribe(result => {
      this.citywisecountryies = result;
    }, error => console.error(error));
  }

  onorgSelect(orgidevent) {
    this.orgIdchnge = orgidevent.target.value;
    this.http.get(environment.baseUrl + '/api/Master/GetBranchLocationList?organizationId=' + this.orgIdchnge).subscribe(result => {
      this.branchlocation = result;
    }, error => console.error(error));
  }

  peraddrerss(e){
    if(e.target.checked){
     this.perhouseno=this.basicinfo_form.value.houseno;
     this.perhousename=this.basicinfo_form.value.housename;
     this.perstreet=this.basicinfo_form.value.road;
     this.percountry=this.basicinfo_form.value.country;
     this.perstate=this.basicinfo_form.value.state;
     this.percity=this.basicinfo_form.value.city;
     this.perpin=this.basicinfo_form.value.pincode;
    }
    else{
      this.perhouseno='';
     this.perhousename='';
     this.perstreet='';
     this.percountry='';
     this.perstate='';
     this.percity='';
     this.perpin='';    
    }
  }

  ondepartmentSelect(eventdepart) {
    this.eventIdchnge = eventdepart.target.value;
    this.http.get(environment.baseUrl + '/api/Master/GetDivisionList?DepartmentId=' + this.eventIdchnge).subscribe(result => {
      this.division = result;
    }, error => console.error(error));
  }
  // convenience getter for easy access to form fields
  get f() { return this.basicinfo_form.controls; }

  onSubmit() {
    this.joiningDate= $("#joindate").val();
    this.dateBirth= $("#datebirth").val(); 
    this.basicmodal = {
      "employeeId": this.basicinfo_form.value.empid,
      "userId": this.basicinfo_form.value.punchid,   
      "biometricId": "",
      "userName": this.basicinfo_form.value.userName,
      "firstName": this.basicinfo_form.value.firstname,
      "middleName": this.basicinfo_form.value.middleName,
      "lastName": this.basicinfo_form.value.lastName,
      "gender": this.basicinfo_form.value.gender,
      "DOB": this.dateBirth,
      "DOJ": this.joiningDate,
      "officialEmailId": this.basicinfo_form.value.emailid,
      "departmentId": this.basicinfo_form.value.department,
      "divisionId": this.basicinfo_form.value.division,
      "designationId": this.basicinfo_form.value.designation,
      "locationId": this.basicinfo_form.value.branchlocation,
      "reportTo": this.basicinfo_form.value.reportingto,
      "organizationId": this.basicinfo_form.value.company,
      "roleId": this.basicinfo_form.value.assignedrole,
      "type": this.basicinfo_form.value.type,
      "status": this.basicinfo_form.value.empstatus,
      "officialMobileNo": this.basicinfo_form.value.officialMobileNo,
      "extentionNumber": this.basicinfo_form.value.extentionNumber,
      "presentAddressResidenceNo": this.basicinfo_form.value.houseno,
      "presentAddressResidenceName": this.basicinfo_form.value.housename,
      "presentAddressStreet": this.basicinfo_form.value.road,
      "presentAddressCountry": this.basicinfo_form.value.country,
      "presentAddressState": this.basicinfo_form.value.state,
      "presentAddressCity": this.basicinfo_form.value.city,
      "presentAddressPincode": this.basicinfo_form.value.pincode,
      "permanentAddressResidenceNo":  this.basicinfo_form.value.permanent_houseno,
      "permanentAddressResidenceName": this.basicinfo_form.value.permanent_housename,
      "permanentAddressStreet": this.basicinfo_form.value.permanent_road,
      "permanentAddressCountry": this.basicinfo_form.value.permanentAddressCountry,
      "permanentAddressState": this.basicinfo_form.value.permanentAddressState,
      "permanentAddressCity": this.basicinfo_form.value.permanentAddressCity,
      "permanentAddressPincode": this.basicinfo_form.value.permanent_pincode,
      "createdDate": this.Datelogs,
      "modifiedDate": this.Datelogs,
      "createdBy":sessionStorage.getItem('biometrics'),
      "modifiedBy":sessionStorage.getItem('biometrics'),
      "deleted": "0"
    };
    console.log(this.basicmodal);

    this.submitted = true
    //stop here if form is invalid
    if (!this.basicinfo_form.valid) {
      return false;
    } else if (this.basicinfo_form.valid) {
      this.http.post(environment.baseUrl + '/api/EIM/InsertUpdateEmployeeBasicInfo', this.basicmodal).subscribe((res: Response) => {
        console.log(res["biometricId"]);
        localStorage.setItem('addempbiometrics', res["biometricId"]);
        alert('employee add successfully');
      }, error => console.error(error));
    }

  }


  GetFormdata(editbioid){
   this.biometricids = editbioid;
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeInfoByBiometricId?biomatricId=' + this.biometricids).subscribe((res: any) => {
      console.log("edit employee Rule");
      console.log(res.employee);
      this.basicinfo_form.setValue({
        empid: res.employee.employeeId,
        punchid: res.employee.userId,   
     
        userName: res.employee.userName,
        firstname: res.employee.firstName,
        middleName: res.employee.middleName,
        lastName: res.employee.lastName,
        gender: res.employee.gender,
        DOB: res.employee.DOB,
        joiningdate: res.employee.DOJ,
        emailid: res.employee.officialEmailId,
        department : res.employee.departmentId,
        division:res.employee.divisionId,    
        designation: res.employee.designationId,
        branchlocation: res.employee.locationId,
        reportingto: res.employee.reportTo,
        company: res.employee.organizationId,
        assignedrole: res.employee.roleId,
        type: res.employee.type,
        empstatus: res.employee.status,
        officialMobileNo: res.employee.officialMobileNo,
        extentionNumber: res.employee.extentionNumber,
        houseno : res.employee.presentAddressResidenceNo,
        housename:res.employee.presentAddressResidenceName,
        road: res.employee.presentAddressStreet,
        country: res.employee.presentAddressCountry,
        state: res.employee.presentAddressState,
        city: res.employee.presentAddressCity,
        pincode : res.employee.presentAddressPincode,
        permanent_houseno:  res.employee.permanentAddressResidenceNo,
        permanent_housename: res.employee.permanentAddressResidenceName,
        permanent_road: res.employee.permanentAddressStreet,
        permanentAddressCountry : res.employee.permanentAddressCountry,
        permanentAddressState: res.employee.permanentAddressState,
        permanentAddressCity: res.employee.permanentAddressCity,
        permanent_pincode: res.employee.permanentAddressPincode,
        createdDate: this.Datelogs,
        modifiedDate: this.Datelogs,
        createdBy:sessionStorage.getItem('biometrics'),
        modifiedBy:sessionStorage.getItem('biometrics'),
        deleted: "0",
        biometricId: res.employee.biometricId
      });
    });
  }


 
}
