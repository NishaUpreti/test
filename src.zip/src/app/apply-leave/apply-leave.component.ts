import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ApplyLeaveModel } from '../model/apply-leave-model';
import { formatDate } from '@angular/common';
declare function datetimeFunc(): any ;
declare function select2Func(): any ;
declare function onlyTimeFunc(): any ;

declare var jquery: any;

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.css']
})
export class ApplyLeaveComponent implements OnInit {
  @Output() getApplyLeaveEvent = new EventEmitter<string>();
  stringTimeFrom: string;
  stringTimeTo: string;

  callParent(): void {
    this.getApplyLeaveEvent.next();
  }


  applyLeaveForm: FormGroup;
  submitted = false;
  Datelogs: any;
  private ApplyLeaveModel: ApplyLeaveModel;
  endValue: any;
  startValue: any;
  biometrics: string;
  leaveTypeList: Response;
  leaveStatusList: Response;
  leaveTypeId: any;
  timeTo: string | number | string[];
  timeFrom: string | number | string[];

  constructor(private http: HttpClient, private formBuilder: FormBuilder) { }
 
  ngOnInit() {
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.applyLeaveForm = this.formBuilder.group({
      FromDate: [],
      ToDate: [],
      hourfrom: [],
      hourto: [],
      description: ['', [Validators.required]],
      fullOrHalfDay: ['', [Validators.required]],
      leaveTypeId: ['', [Validators.required]],
      totalDaysOrHours: []
  });

  this.getLeaveType();
  this.getLeaveStatus();
  }
  ngAfterViewInit(): void {
    datetimeFunc();
    select2Func();
    onlyTimeFunc();
  }
  getLeaveType(){
    this.http.get(environment.baseUrl + '/api/Master/GetLeaveTypeList').subscribe((res: Response) => {
      // console.log(res);
      this.leaveTypeList = res;
    });
  }
  getLeaveStatus(){
    this.http.get(environment.baseUrl + '/api/Master/GetLeaveStatusList').subscribe((res: Response) => {
      // console.log(res);
      this.leaveStatusList = res;
    });
  }
  
  getleaveTypes(event: any): void{
    this.leaveTypeId = (<HTMLElement>event.target)['options']
      [(<HTMLElement>event.target)['options'].selectedIndex].value;
  }
  
  endDateValidate(){
    if($("#startDates").val() != ""){
      this.endValue = $("#endDates").val();
      this.startValue = $("#startDates").val();
      if ((Date.parse(this.endValue) < Date.parse(this.startValue))) {
        alert("End date should be greater than or equal Start date");
        $("#endDates").val('');
      }
    }
    else{
      alert("please select Start date ");
      $("#endDates").val('');
    }
  }
  getTimeTo(): void{
    this.timeTo = $("#timeTo").val();
    if(this.timeTo != null ){
      this.timeTo = this.timeTo.toString();
      this.stringTimeTo = this.timeTo;
    }
  }
  getTimeFrom(): void{
    this.timeFrom = $("#timeFrom").val();
    if(this.timeFrom != null ){
      this.timeFrom = this.timeFrom.toString();
      this.stringTimeFrom = this.timeFrom;
    }
  }
  // convenience getter for easy access to form fields
  get f() { return this.applyLeaveForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.applyLeaveForm.invalid) {
        return;
    }
    else if (this.applyLeaveForm.valid) {
      this.biometrics= sessionStorage.getItem('biometrics');
      this.ApplyLeaveModel = {
        id: null,
        leaveGroupId: null,
        requestId: null,
        biometricId: this.biometrics,
        leaveTypeId: parseInt(this.leaveTypeId),
        description: this.applyLeaveForm.value.description,
        leaveStatusId: 1,
        fullOrHalfDay: this.applyLeaveForm.value.fullOrHalfDay,
        FromDate: this.startValue,
        ToDate: this.endValue,
        hourfrom: this.stringTimeFrom,
        hourto: this.stringTimeTo,
        remarks: "",
        DaysOrHours: "",
        totalDaysOrHours: null,
        createdBy: this.biometrics,
        modifiedBy: this.biometrics,
        createdDate: this.Datelogs,
        modifiedDate: this.Datelogs,
        deleted: 0
      }
      console.log(this.ApplyLeaveModel);
      this.http.post(environment.baseUrl + '/api/Leave/InsertLeaveRequest', this.ApplyLeaveModel).subscribe((res:Response) => {
        //debugger;
        //console.log("Applied Leave");
        //console.log(res);
        this.callParent();
        alert(res);
        this.applyLeaveForm.reset();
        this.submitted = false;
      })
    }
  }
}
