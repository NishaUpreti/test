import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { AddActionComponent } from '../add-action/add-action.component';
@Component({
  selector: 'app-add-new-role',
  templateUrl: './add-new-role.component.html',
  styleUrls: ['./add-new-role.component.css']
})
export class AddNewRoleComponent implements OnInit {

  constructor() { }
  @ViewChild(AddActionComponent) child: AddActionComponent;
  @Output() roleEvent = new EventEmitter<string>();
  addrolecancel() {
    this.roleEvent.emit();
  }
  ngOnInit() {
  }
  actioncancelsuccess($event) {
    $('#add_action').modal('hide');
    $('#add_new_role').modal('show');
  }
  addnewaction() {
    this.child.ngOnInit();
  }

}
