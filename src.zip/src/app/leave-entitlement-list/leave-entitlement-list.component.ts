import {SelectionModel} from '@angular/cdk/collections';
import { environment } from 'src/environments/environment';
import { Component, OnInit, ViewChild  } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { formatDate } from '@angular/common';
declare var jquery: any;

@Component({
  selector: 'app-leave-entitlement-list',
  templateUrl: './leave-entitlement-list.component.html',
  styleUrls: ['./leave-entitlement-list.component.css']
})
export class LeaveEntitlementListComponent implements OnInit {
  biometrics: string;
  currentYear: any;
  currentYearFrom: string;
  currentYearTo: string;
  updateLeaveStatusModel: any;


  displayedColumns: string[] = ['select', 'sNo', 'leaveStatus', 'leaveGroupId', 'ManagerName', 'EmployeeName', 'NoOfDays', 'Duration'];
  
  displayedColumnsSearch: string[] = ['selectSearch', 'sNoSearch', 'leaveStatusSearch', 'leaveGroupIdSearch', 'ManagerNameSearch', 'EmployeeNameSearch', 'NoOfDaysSearch', 'DurationSearch'];

  fleetData:any = [];
  dataSource = new MatTableDataSource(this.fleetData);
  selection = new SelectionModel(this.fleetData);
  //leaveStatus: any;
  defaultStatus: any;
  teamLeavelist: boolean;
  leaveList: boolean;
  teamLeaveHeading: boolean;
  leaveHeading: boolean;

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.sNo + 1}`;
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults 
    this.dataSource.filter = filterValue;
  }


  constructor(private http: HttpClient) { 
    this.biometrics= sessionStorage.getItem('biometrics');
    this.currentYear = (new Date()).getFullYear();
    this.currentYearFrom = this.currentYear + '-01-01';
    this.currentYearTo = this.currentYear + '-12-31';
    console.log(this.biometrics);
    console.log(this.currentYearFrom);
    console.log(this.currentYearTo);
    this.getLeaveList();
  }

  sNoFilter = new FormControl('');
  empNameFilter = new FormControl('');
  dateAbsFilter = new FormControl('');
  totalDayFilter = new FormControl('');
  durationFilter = new FormControl('');
  leaveTypeFilter = new FormControl('');
  leaveStatusFilter = new FormControl('');
  descriptionFilter = new FormControl('');
  modifiedByFilter = new FormControl('');
  modifiedDateFilter = new FormControl('');
  appliedDateFilter = new FormControl('');
  fromDateFilter = new FormControl('');
  toDateFilter = new FormControl('');
  attachmentsFilter = new FormControl('');
  empIdFilter = new FormControl('');
  leavePlanFilter = new FormControl('');
  fromHoursFilter = new FormControl('');
  toHoursFilter = new FormControl('');
  totalHoursFilter = new FormControl('');

  ngOnInit() {
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.defaultStatus = "Pending";
   }
   getLeaveList(){
    //alert("hello");
    this.http.get(environment.baseUrl + '/api/Leave/GetEmployeeLeaveRequestList?biometricId=' + this.biometrics + '&' + 'FromDate=' + this.currentYearFrom + '&' + 'ToDate=' + this.currentYearTo).subscribe((res: any) => {
      console.log(res);
      this.fleetData = res;
      this.dataSource.data = this.fleetData;
    });
  }
  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
