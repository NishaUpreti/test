import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveEntitlementListComponent } from './leave-entitlement-list.component';

describe('LeaveEntitlementListComponent', () => {
  let component: LeaveEntitlementListComponent;
  let fixture: ComponentFixture<LeaveEntitlementListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaveEntitlementListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaveEntitlementListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
