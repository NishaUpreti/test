import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
declare function datetimeFunc(): any ;
declare function select2Func(): any ;
declare function onlyTimeFunc(): any ;

declare var jquery: any;


@Component({
  selector: 'app-docupload',
  templateUrl: './docupload.component.html',
  styleUrls: ['./docupload.component.css']
})
export class DocuploadComponent implements OnInit {   

  documentupload_form: FormGroup;
  submitted = false;
  Datelogs: string;
  basicmodal: { "id": any; "documentId": any; "documentName": string; "documentType": string; "module": string; "moduleId": string; "createdBy": string; "createdDate": string; "modifiedBy": string; "modifiedDate": string; "deleted": number; "documentCategory": any; "doc": any; };
  files:FileList; 
  docex: string[];
  allemployment=[];
  EmployeeUnCompleteDetailsViewModel: { "personal": {}; "employement": any; "qualification": any[]; "target": {}; "incentive": {}; "payroll": {};"document" };
  image:any;
  datarest: { "id": any; "documentId": any; "documentName": string; "documentType": string; "module": string; "moduleId": string; "createdBy": string; "createdDate": string; "modifiedBy": string; "modifiedDate": string; "deleted": number; "documentCategory": number; "doc": string; };
  stringconvert: string[];
  alldocuments: any[];
  constructor(public formBuilder: FormBuilder,private http: HttpClient) { }

  ngOnInit() {
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.documentupload_form=this.formBuilder.group({
      selectfile_doc:[''],
      doc_name:['', Validators.required]
    });

  }
  ngAfterViewInit(): void {
    select2Func();
  }
  getFiles(event){ 
    this.files = event.target.files;
    this.docex= this.files[0].name.split('.')
    if (this.files[0].size > 0) {
      this.getBase64(event.target);
    }
} 
  
  onSubmit() {
  this.EmployeeUnCompleteDetailsViewModel = {
    "personal": null,
    "employement": [],
    "qualification": [],
    "target": null,
    "incentive": null,
    "payroll": null,
    "document":this.allemployment 
  }

  console.log(this.EmployeeUnCompleteDetailsViewModel);

          this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo', this.EmployeeUnCompleteDetailsViewModel).subscribe((res: Response) => {
         // console.log(res["biometricId"]);
         alert('document upload successfully');

          localStorage.setItem('biometrics', res["biometricId"]);
          window.location.reload();
        }, error => console.error(error));
    };


  getBase64(inputValue: any): void  {
    var file:File = inputValue.files[0];
    var myReader:FileReader = new FileReader();
    myReader.readAsDataURL(file);
    myReader.onloadend = (e) => {
      this.image = myReader.result as string;

     // fileReader.result as string;
     this.stringconvert = this.image.split('base64,');
      this.basicmodal = {
        "id": null,
        "documentId": null,
        "documentName":this.files[0].name,
        "documentType": this.docex[1],
        "module": "Employee",
        "moduleId": "3D448F60-484F-428D-AEF8-39AB633D02D6",
        "createdBy": sessionStorage.getItem('biometrics'),
        "createdDate":this.Datelogs,   
        "modifiedBy": sessionStorage.getItem('biometrics'),
        "modifiedDate":this.Datelogs,
        "deleted": 0,
        "documentCategory":this.documentupload_form.value.selectfile_doc,
        "doc": this.stringconvert[1]
      }
      console.log(this.basicmodal);
      this.allemployment.push(this.basicmodal);
    }
  
      }

      adddocument(){
        this.alldocuments= this.allemployment
        this.documentupload_form.reset();
      }
    }


    // readThis(inputValue: any): void {
    //   var file:File = inputValue.files[0];
    //   var myReader:FileReader = new FileReader();
    
    //   myReader.onloadend = (e) => {
    //     this.image = myReader.result;
    //   }
    //   myReader.readAsDataURL(file);
    // }




