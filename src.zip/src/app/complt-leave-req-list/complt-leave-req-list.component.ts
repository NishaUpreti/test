import {SelectionModel} from '@angular/cdk/collections';
import { environment } from 'src/environments/environment';
import { Component, OnInit, ViewChild, Input, Output, EventEmitter  } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { formatDate } from '@angular/common';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'app-complt-leave-req-list',
  templateUrl: './complt-leave-req-list.component.html',
  styleUrls: ['./complt-leave-req-list.component.css']
})
export class CompltLeaveReqListComponent implements OnInit {
  @Input() TeamleaveStatusId;

  @Input() leaveGroupIdInput: any;
  @Input() compltLeaveList: boolean;
  @Output() compltLeaveListChange = new EventEmitter<boolean>();
  @Output() LeaveListGet = new EventEmitter<any>();

  biometrics: string;
  currentYear: any;
  currentYearFrom: string;
  currentYearTo: string;
  updateLeaveStatusModel: [{
    "leaveGroupId": string;
    "requestId": string;
    "LeaveDate": string;
		"biometricId": string;
		"remarks": string;
		"leaveStatusId": number;
		"modifiedBy": string;
    "deleted": string;
    "All": number;
    "Duration": string
  }];

  displayedColumns: string[] = ['select', 'sNo', 'leaveStatus',  'LeaveDate', 'NoOfDays', 'LeaveType',  'Remarks', 'LeaveStatusId', 'LeaveTypeId', 'leaveGroupId', 'requestId'];
  
  displayedColumnsSearch: string[] = ['selectSearch', 'sNoSearch', 'leaveStatusSearch', 'LeaveDateSearch', 'NoOfDaysSearch', 'LeaveTypeSearch', 'RemarksSearch', 'LeaveStatusIdSearch', 'LeaveTypeIdSearch', 'leaveGroupIdSearch', 'requestIdSearch'];

  fleetData:any = [];
  dataSource = new MatTableDataSource(this.fleetData);
  selection = new SelectionModel(this.fleetData);
  //leaveStatus: any;
  defaultStatus: any;
  teamLeavelist: boolean;
  leaveList: boolean;
  teamLeaveHeading: boolean;
  leaveHeading: boolean;
  leaveId: any;
  leaveGrpId: any;
  leaveDate: any;
  requestId: any;
  addRemarkspopup: boolean;
  comLeaveReqListSec: boolean;
  addRemarksSec: boolean;


   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.sNo + 1}`;
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults 
    this.dataSource.filter = filterValue;
  }

  constructor(private http: HttpClient) { 
    debugger;
    this.biometrics= sessionStorage.getItem('biometrics');
    this.currentYear = (new Date()).getFullYear();
    this.currentYearFrom = this.currentYear + '-01-01';
    this.currentYearTo = this.currentYear + '-12-31';
  }

  sNoFilter = new FormControl('');
  empNameFilter = new FormControl('');
  dateAbsFilter = new FormControl('');
  totalDayFilter = new FormControl('');
  durationFilter = new FormControl('');
  leaveTypeFilter = new FormControl('');
  leaveStatusFilter = new FormControl('');
  descriptionFilter = new FormControl('');
  modifiedByFilter = new FormControl('');
  modifiedDateFilter = new FormControl('');
  appliedDateFilter = new FormControl('');
  fromDateFilter = new FormControl('');
  toDateFilter = new FormControl('');
  attachmentsFilter = new FormControl('');
  empIdFilter = new FormControl('');
  leavePlanFilter = new FormControl('');
  fromHoursFilter = new FormControl('');
  toHoursFilter = new FormControl('');
  totalHoursFilter = new FormControl('');

  ngOnInit() {
    debugger;
    if(this.compltLeaveList){
      $('#CompleteLeaveRequest').modal('show'); 
    }
    console.log(this.leaveGroupIdInput);
    debugger;
    this.getCompleteLeaveList();
    this.comLeaveReqListSec = true;
    this.addRemarksSec = false;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.defaultStatus = "Pending";
   }
  
   closeComLeaveList(){
    if(this.compltLeaveList){
      $('#CompleteLeaveRequest').modal('hide'); 
      this.compltLeaveList = false;
      this.compltLeaveListChange.emit(this.compltLeaveList);
    }
   }
   getCompleteLeaveList(){
    debugger;
    //alert(this.leaveGroupIdInput);
    this.http.get(environment.baseUrl + '/api/Leave/GetLeaveDetailsByGroupId?leaveGroupId=' + this.leaveGroupIdInput).subscribe((res: any) => {
      console.log(res);
      this.fleetData = res;
      this.dataSource.data = this.fleetData;
      //this.leaveGroupIdInput = null;
    });
  }
  addRemarksModal(){
    this.comLeaveReqListSec = false;
    this.addRemarksSec = true;
  }
  closeRemarksSec(){
    this.comLeaveReqListSec = true;
    this.addRemarksSec = false;
  }
  changeStatus(event, id, groupId, reqstId, date): void{
    debugger;
    this.leaveId = id;
    this.leaveGrpId = groupId;
    this.requestId = reqstId;
    this.leaveDate = date;
    this.updateOneLeaveStatus(); 
  }
  updateOneLeaveStatus(){
    debugger;

    this.updateLeaveStatusModel = [{
      "leaveGroupId": this.leaveGrpId,
      "requestId": this.requestId,
      "LeaveDate": this.leaveDate,
      "biometricId": this.biometrics,
      "remarks": "test",
      "leaveStatusId": this.leaveId,
      "modifiedBy": this.biometrics,
      "deleted": "0",
      "All": 0,
      "Duration": null

    }];
    console.log(this.updateLeaveStatusModel);
    this.http.post(environment.baseUrl + '/api/Leave/UpdateLeaveStatus', this.updateLeaveStatusModel).subscribe((res:Response) => {
      console.log("Leave status Updated");
      console.log(res);
      alert("leave status updated.");
      this.LeaveListGet.next();
      this.getCompleteLeaveList();
    })
  }
  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
