import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompltLeaveReqListComponent } from './complt-leave-req-list.component';

describe('CompltLeaveReqListComponent', () => {
  let component: CompltLeaveReqListComponent;
  let fixture: ComponentFixture<CompltLeaveReqListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompltLeaveReqListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompltLeaveReqListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
