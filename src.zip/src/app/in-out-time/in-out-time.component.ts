import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-out-time',
  templateUrl: './in-out-time.component.html',
  styleUrls: ['./in-out-time.component.css']
})
export class InOutTimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.loadScript('../assets/js/jquery.dataTables.min.js');
    this.loadScript('../assets/js/dataTables.bootstrap.min.js');
    this.loadScript('../assets/js/inOutTime.js');
  }


  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
