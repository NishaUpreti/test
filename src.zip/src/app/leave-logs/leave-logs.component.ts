import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-logs',
  templateUrl: './leave-logs.component.html',
  styleUrls: ['./leave-logs.component.css']
})
export class LeaveLogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
