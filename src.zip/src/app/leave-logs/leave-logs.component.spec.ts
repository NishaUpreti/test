import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveLogsComponent } from './leave-logs.component';

describe('LeaveLogsComponent', () => {
  let component: LeaveLogsComponent;
  let fixture: ComponentFixture<LeaveLogsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeaveLogsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaveLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
