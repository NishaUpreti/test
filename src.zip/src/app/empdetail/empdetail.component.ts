import { Component, OnInit,Pipe,PipeTransform } from '@angular/core';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import {  HttpClient,HttpHeaders } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-empdetail',
  templateUrl: './empdetail.component.html',
  styleUrls: ['./empdetail.component.css']
})
export class EmpdetailComponent implements OnInit {
  empdetail_form: FormGroup;
  submitted = false;
  Datelogs: string;
  Date: string;
  basicmodal:any;
  role:any;
  allemployment = [];
  employmodal: {"biometricId": string; "employer": any; "designation": any; "fromDate": any; "toDate": any; "NumberOfMonth ": string; "kra": string; "reasonForChange": string; "createdDate": string; "modifiedDate": string; "createdBy": string; "modifiedBy": string; "deleted": string;  }
  EmployeeCompleteDetailsViewModel: { "personal": {}; "employement": {}; "qualification": {}; "target": {}; "incentive": {};"payroll":{},"document":[] };
  biometrics: string;
  employmodalss: { "biometricId": string; "employer": any; "designation": any; "fromDate": any; "toDate": any; "NumberOfMonth ": string; "kra": string; "reasonForChange": string; "createdDate": string; "modifiedDate": string; "createdBy": string; "modifiedBy": string; "deleted": string; };

  EmployeeUnCompleteDetailsViewModel: { "personal": {}; "employement": {}; "qualification": {}; "target": {}; "incentive": {};"payroll":{};"document":[] };
  toDatess: string | number | string[];
  frmeDatess: string | number | string[];
  biometricids: any;
 
  constructor(public http:HttpClient , public formBuilder: FormBuilder) { }

  ngOnInit() {
      this.Date = formatDate(new Date(), 'mm-dd-yyyy', 'en');
      this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');

    this.empdetail_form=this.formBuilder.group({  
      companyname:['', Validators.required],
      empdetail_from:[''],
      empdetail_to:[''],
      empdetail_designation:['',Validators.required]  
  });
}

get f() { return this.empdetail_form.controls; }

onSubmit(){

  this.submitted =true
  if (!this.empdetail_form.valid) {
    return false;
} else if(this.empdetail_form.valid){     
  if(this.EmployeeCompleteDetailsViewModel==undefined){
    this.frmeDatess= $("#frmdates").val();
    this.toDatess= $("#todates").val(); 
    this.employmodalss = {
      "biometricId": localStorage.getItem('addempbiometrics'),
      "employer":this.empdetail_form.value.companyname,
      "designation":this.empdetail_form.value.empdetail_designation,
      "fromDate":this.frmeDatess,
      "toDate":this.toDatess,
      "NumberOfMonth ":"",
      "kra":"",
      "reasonForChange":"", 
      "createdDate":this.Datelogs,
      "modifiedDate":this.Datelogs,
      "createdBy":sessionStorage.getItem('biometrics'),
      "modifiedBy":sessionStorage.getItem('biometrics'),
      "deleted":"0"
    };

    this.allemployment.push(this.employmodalss);
    this.EmployeeUnCompleteDetailsViewModel = {
      "personal":{},
      "employement":this.allemployment,
      "qualification":[],
      "target":{},
      "incentive":{},
      "payroll":null,
      "document":[]
    }

    this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo',this.EmployeeUnCompleteDetailsViewModel).subscribe((res: Response) => {
      this.empdetail_form.reset();
    }, error => console.error(error));
  }

  else {
    this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo',this.EmployeeCompleteDetailsViewModel).subscribe((res: Response) => {
      this.empdetail_form.reset();
    }, error => console.error(error));
  }
  
}
  }

  GetempdetailFormdata(editbioid){
    this.biometricids = editbioid;
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeInfoByBiometricId?biomatricId=' + this.biometricids).subscribe((res: any) => {
      console.log(res.employement);
      this.empdetail_form.setValue({
        biometricId: localStorage.getItem('addempbiometrics'),
        companyname:res.employement.employer,
        empdetail_designation :res.employement.empdetail_designation,
        empdetail_from:res.employement.fromDate,
        empdetail_to:res.employement.toDate,
        NumberOfMonth:"",
        kra:"",
        reasonForChange:"", 
        createdDate:res.employement.createdDate,
        modifiedDate:res.employement.modifiedDate,
        createdBy:sessionStorage.getItem('biometrics'),
        modifiedBy:sessionStorage.getItem('biometrics'),
        deleted:"0"
       });
    });
  }

  addExperience() {
    this.frmeDatess= $("#frmdates").val();
    this.toDatess= $("#todates").val(); 

    this.employmodal = {
      "biometricId": localStorage.getItem('addempbiometrics'),
      "employer":this.empdetail_form.value.companyname,
      "designation":this.empdetail_form.value.empdetail_designation,
      "fromDate": this.frmeDatess,
      "toDate":this.toDatess,
      "NumberOfMonth ":"",
      "kra":"",
      "reasonForChange":"", 
      "createdDate":this.Datelogs,
      "modifiedDate":this.Datelogs,
      "createdBy":sessionStorage.getItem('biometrics') ,
      "modifiedBy":sessionStorage.getItem('biometrics'),
      "deleted":"0"
    };  

    this.allemployment.push(this.employmodal);
    this.EmployeeCompleteDetailsViewModel = {
      "personal":{},
      "employement":this.allemployment,
      "qualification":[],
      "target":{},
      "incentive":{},
      "payroll":{},
      "document": []
    }

    this.empdetail_form.reset();

}

}

