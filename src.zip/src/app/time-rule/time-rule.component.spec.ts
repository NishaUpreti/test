import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeRuleComponent } from './time-rule.component';

describe('TimeRuleComponent', () => {
  let component: TimeRuleComponent;
  let fixture: ComponentFixture<TimeRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TimeRuleComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
