import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { AddTimeRuleComponent } from '../add-time-rule/add-time-rule.component';

@Component({
  selector: 'app-time-rule',
  templateUrl: './time-rule.component.html',
  styleUrls: ['./time-rule.component.css']
})
export class TimeRuleComponent implements OnInit {
  displayedColumns: string[] = ['select', 'sNo', 'Intime From', '	Intime To', 'Out Time From', 'Out Time To', 'Full Day Duration',
    'Halfday Duration', 'Lunch Time From', 'Lunch Time To', 'Maximum In-Time allowed for afternoon', 'Applicable TimeZone', 'Late Exemption Time Duration', 'toDate', 'attachments', 'empId',
    'leavePlan', 'fromHours', 'toHours', 'totalHours'];

  displayedColumnsSearch: string[] = ['select', 'sNo', 'IntimeFromSearch', '	IntimeToSearch', 'OutTimeFrom', 'Out Time To', 'Full Day Duration',
    'Halfday Duration', 'Lunch Time From', 'Lunch Time To', 'Maximum In-Time allowed for afternoon', 'Applicable TimeZone', 'Late Exemption Time Duration', 'toDate', 'attachments', 'empId',
    'leavePlan', 'fromHours', 'toHours', 'totalHours'];
  constructor() { }
  @ViewChild(AddTimeRuleComponent) child: AddTimeRuleComponent;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {
  }
  ShowAddTimeRule() {
    this.child.ngOnInit();
  }
}
