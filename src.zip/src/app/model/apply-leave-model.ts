export class ApplyLeaveModel {
    id: number;
    leaveGroupId: number;
    requestId: number;
    biometricId: string;
    leaveTypeId: number;
    description: string;
    leaveStatusId: number;
    fullOrHalfDay: string;
    FromDate: string;
    ToDate: string;
    hourfrom: string;
    hourto: string;
    remarks: string;
    DaysOrHours: string;
    totalDaysOrHours: number;
    createdBy: string;
    modifiedBy: string;
    createdDate: string;
    modifiedDate: string;
    deleted: number
}
