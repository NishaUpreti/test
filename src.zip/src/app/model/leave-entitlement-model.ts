export class LeaveEntitlementModel {
    "id": number;
    "biometricId": string;
    "organizationId": string;
    "locationId": number;
    "leaveTypeId": number;
    "startDate": string;
    "endDate": string;
    "lwp": number;
    "publicHolidays": number;
    "extraLeave": number;
    "totalLeave": number;
    "takenLeave": number;
    "description": string;
    "createdBy": string;
    "modifiedBy": string;
    "createdDate": string;
    "modifiedDate": string;
    "deleted": number;
    "totalhours": number
}
