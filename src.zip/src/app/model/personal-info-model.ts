export class PersonalInfoModel {
    biometricId: string;
    mobileNumber: any;
    phoneOther: any;
    personalEmail: any;
    alternateEmail: any;
    gender: any;
    maritalStatus: any;
    aadharCardNumber: any;
    passportNumber: any;
    passportValidity: any;
    physicalChallenged: string;
//     name: any;
//    contact: any
    pancardNo:any;
    createdBy:any;
	createdDate:any;
	modifiedBy:any;
	modifiedDate:any;
	deleted:any

}
