import { ApplyLeaveModel } from './apply-leave-model';

describe('ApplyLeaveModel', () => {
  it('should create an instance', () => {
    expect(new ApplyLeaveModel()).toBeTruthy();
  });
});
