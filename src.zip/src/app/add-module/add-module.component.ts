import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-module',
  templateUrl: './add-module.component.html',
  styleUrls: ['./add-module.component.css']
})
export class AddModuleComponent implements OnInit {

  constructor() { }
  @Output() ModuleEvent = new EventEmitter<string>();
  addmodulecancel() {
    this.ModuleEvent.emit();
  }
  ngOnInit() {
  }

}
