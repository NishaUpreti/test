import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { PersonalInfoModel } from '../model/personal-info-model'


@Component({
  selector: 'app-personalinfo',
  templateUrl: './personalinfo.component.html',
  styleUrls: ['./personalinfo.component.css']
})
export class PersonalinfoComponent implements OnInit {
  personalinfo_form: FormGroup;
  pancardNo:any;
  submitted = false;
  private PersonalInfoModel: PersonalInfoModel;
  EmployeeCompleteDetailsViewModel: { "personal": PersonalInfoModel; "employement": {}; "qualification": {}; "target": {}; "incentive": {};"payroll":{}
  ,"document":{} };
  Datelogs: string;
  biometrics: string;
  passortvalid: string | number | string[];
  biometricids: any;

  constructor(private http: HttpClient, public SharingService: SharingService, public formBuilder: FormBuilder) { }

  ngOnInit() {
    localStorage.getItem('addempbiometrics');
    console.log(localStorage.getItem('addempbiometrics'));

    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.personalinfo_form=this.formBuilder.group({
      mobileNumber:['', Validators.required],
      phoneOther:[''],
      personalEmail:['',[Validators.required, Validators.email]],
      alternateEmail:[''],
      //gender:['',[Validators.required]],
      maritalStatus:[''],
      aadharCardNumber:['', Validators.required],
      passportNumber:[''],
      passportValidity:[''],
      physicalChallenged:[''],
      name:['',Validators.required],
      relation:['',Validators.required],
      contact:['',Validators.required],
    });
  }

  get f() { return this.personalinfo_form.controls; }

  onSubmit() {
   localStorage.getItem('addempbiometrics');
   this.passortvalid= $("#passvalid").val(); 
   
    this.PersonalInfoModel = {
      "biometricId":  localStorage.getItem('addempbiometrics'),
      "mobileNumber": ""+this.personalinfo_form.value.mobileNumber+"",
      "phoneOther": ""+this.personalinfo_form.value.phoneOther+"",
      "personalEmail":this.personalinfo_form.value.personalEmail,
      "alternateEmail":this.personalinfo_form.value.alternateEmail,
      "gender":'',
      "maritalStatus":this.personalinfo_form.value.maritalStatus,
      "aadharCardNumber":""+this.personalinfo_form.value.aadharCardNumber+"",
      "passportNumber":this.personalinfo_form.value.passportNumber,
      "passportValidity":this.passortvalid,
      "physicalChallenged":this.personalinfo_form.value.physicalChallenged,
			"pancardNo":"",
			"createdBy":sessionStorage.getItem('biometrics'),
			"createdDate":this.Datelogs,
			"modifiedBy":sessionStorage.getItem('biometrics'), 
			"modifiedDate":this.Datelogs,
      "deleted":0,
    };

    this.EmployeeCompleteDetailsViewModel = {                                                                                                    
    "personal":this.PersonalInfoModel,
    "employement": [],
    "qualification": [],
    "target": null,
    "incentive": null,
    "payroll": null,
    "document":[]
      }

      this.submitted =true
      if (!this.personalinfo_form.valid) {
        return false;
    } else if(this.personalinfo_form.valid){
      this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo',this.EmployeeCompleteDetailsViewModel).subscribe((res: Response) => {
        console.log(res);
      }, error => console.error(error));
    }
   }
   GetpersonalFormdata(editbioid){
    this.biometricids = editbioid;
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeInfoByBiometricId?biomatricId=' + this.biometricids).subscribe((res: any) => {
      console.log("edit employee Rule");
      console.log(res);
      this.personalinfo_form.setValue({
        
        mobileNumber: res.personal.mobileNumber,
        phoneOther: res.personal.phoneOther+"",
        personalEmail:res.personal.personalEmail,
        alternateEmail:res.personal.alternateEmail,
        gender:'',
        maritalStatus:res.personal.maritalStatus,
        aadharCardNumber:res.personal.aadharCardNumber+"",
        passportNumber:res.personal.passportNumber,
        passportValidity:res.personal.passportValidity,
        physicalChallenged:res.personal.physicalChallenged,
        pancardNo:res.personal.pancardNo,
        createdBy:"",
        createdDate:"",
        modifiedBy:sessionStorage.getItem('biometrics'), 
        modifiedDate:this.Datelogs,
        deleted:0,
        name:"",
        relation:"",
        contact:"",
        biometricId:  localStorage.getItem('addempbiometrics'),
      });
    });

   }
 
}
