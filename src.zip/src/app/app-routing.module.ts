import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { CommonStructureComponent } from './common-structure/common-structure.component';
import { LeaveListComponent } from './leave-list/leave-list.component';
import { LeaveEntitlementListComponent } from './leave-entitlement-list/leave-entitlement-list.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { EmployeeComponent } from './employee/employee.component';
import { LeaveRuleComponent } from './leave-rule/leave-rule.component';
import { AddEntitlementComponent } from './add-entitlement/add-entitlement.component';
import { InOutTimeComponent } from './in-out-time/in-out-time.component';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { TimecompComponent } from './timecomp/timecomp.component';
import { ConfigComponent } from './config/config.component';
import { RolesAndRightsComponent } from './roles-and-rights/roles-and-rights.component';


const routes: Routes = [

  {
    path: '',
    component: LoginComponent
  },
  {
    path: '',
    component: CommonStructureComponent,
    children: [
      { path: 'leave', component: LeaveListComponent },
      { path: 'leaveEntitlementList', component: LeaveEntitlementListComponent },
      { path: 'leaverule', component: LeaveRuleComponent },
      { path: 'inOutTime', component: InOutTimeComponent },
      { path: 'employee', component: EmployeeComponent, pathMatch: 'full' },
      { path: 'addemployee', component: AddemployeeComponent },
      { path: 'employee-profile', component: EmployeeProfileComponent },
      { path: 'timecomp', component: TimecompComponent, pathMatch: 'full' },
      { path: 'config', component: ConfigComponent },
      { path: 'roles-and-rights', component: RolesAndRightsComponent }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
