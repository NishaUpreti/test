import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';
import { AddNewRoleComponent } from '../add-new-role/add-new-role.component';

export interface PeriodicElement {
  Role: string;
  position: number;
  Created_User_Name: string;
  Created_Date: string;
  Modified_Date: string;
  Modified_User_Name: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { position: 1, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
  { position: 2, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
  { position: 3, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
  { position: 4, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
  { position: 5, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
  { position: 6, Role: 'Finance_Export', Created_User_Name: 'Nisha', Created_Date: '12-3-2019', Modified_Date: '12-3-2019', Modified_User_Name: 'neha' },
];

@Component({
  selector: 'app-roles-and-rights',
  templateUrl: './roles-and-rights.component.html',
  // <app-add-new-role (rolecancel1)="rolecancel($event)"></app-add-new-role>',
  styleUrls: ['./roles-and-rights.component.css']
})
export class RolesAndRightsComponent implements OnInit {
  usertype: boolean;
  usergroup: boolean;
  createnewrole: boolean;
  displayedColumns: string[] = ['select', 'position', 'Role', 'Created_User_Name', 'Created_Date', 'Modified_Date', 'Modified_User_Name'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);
  // rolecancel(msg) {
  //   console.log(msg);
  // }
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  checkboxLabel(row?: PeriodicElement): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }
  constructor() { }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(AddNewRoleComponent) child: AddNewRoleComponent;

  ngOnInit() {
    this.usergroup = false;
    this.usertype = false;
    this.createnewrole = false;
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  rolecancelsuccess($event) {
    $('#add_new_role').modal('hide');
    $('#role_rights').show();
  }
  test(msg) {
    console.log(msg);
  }
  selectroletype(event: any) {
    if (event.target.value === 'user') {
      this.usertype = true;
      this.usergroup = false;
      this.createnewrole = false;
    }
    else if (event.target.value === 'group') {
      this.usergroup = true;
      this.usertype = false;
    }
    else if (event.target.value === 'roleselect') {
      this.usergroup = false;
      this.usertype = false;
      this.createnewrole = false;
    }
  }
  selectgrouptype(event: any) {
    if (event.target.value === 'selectgroup') {
      this.createnewrole = false;
    }
  }
  createnewgroup() {
    this.createnewrole = false;
  }
  Addnewrole() {
    this.child.ngOnInit();
  }
  newgroup() {
    this.createnewrole = true;
  }
}
