import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RolesAndRightsComponent } from './roles-and-rights.component';

describe('RolesAndRightsComponent', () => {
  let component: RolesAndRightsComponent;
  let fixture: ComponentFixture<RolesAndRightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RolesAndRightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RolesAndRightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
