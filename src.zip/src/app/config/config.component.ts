import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {
  submitted = false;
  config_form: FormGroup;
  config_model: any;
  router: any;
  constructor(private http: HttpClient, public SharingService: SharingService, public _formBuilder: FormBuilder) {

  }
  ngOnInit() {
    this.config_form = this._formBuilder.group({
      encryptionkey: ['', Validators.required],
      superadminName: ['', Validators.required],
      superadminPassword: ['', Validators.required],
      servercredential: ['', Validators.required],
      database: ['', Validators.required],
      userid: ['', Validators.required],
      password: ['', Validators.required],
      logintype: ['', Validators.required],
      adserver: ['', Validators.required],
      aduserid: ['', Validators.required],
      aduserpassword: ['', Validators.required],
      uploadtype: [''],
      serverdetail: ['', Validators.required],
      databasename: ['', Validators.required],
      collection: ['', Validators.required],
      sitepath: ['', Validators.required],
      username: ['', Validators.required],
      password1: ['', Validators.required]
    })
  }
  get f() { return this.config_form.controls; }
  onSubmit() {
    //  alert();
    this.config_model = {
      "EncryptionKey": this.config_form.value.encryptionkey,
      "SuperAdmin": this.config_form.value.superadminName,
      "SuperAdminPassword": this.config_form.value.superadminPassword,
      "ApplicationServerCredentials": this.config_form.value.servercredential,
      "ApplicationDatabase": this.config_form.value.database,
      "ApplicationUserId": this.config_form.value.userid,
      "ApplicationUserPassword": this.config_form.value.password,
      "ApplicationLoginType ": this.config_form.value.logintype,
      "ADServerCredentials": this.config_form.value.adserver,
      "ADUserId": this.config_form.value.aduserid,
      "ADPassword": this.config_form.value.aduserpassword,
      "upload": "this.config_form.value.uploadtype",
      "DocServerCredentials": this.config_form.value.serverdetail,
      "DocDatabaseName": this.config_form.value.databasename,
      "DocTableCollectionName": this.config_form.value.collection,
      "DocSitePath": this.config_form.value.sitepath,
      "DocUserName": this.config_form.value.username,
      "DocUserPassword": this.config_form.value.password1,
      "ModifiedBy": sessionStorage.getItem('biometrics'),
    }
    this.submitted = true
    //stop here if form is invalid
    if (this.config_form.invalid) {
      return;
    }
    else if (this.config_form.valid) {
      this.http.post(environment.baseUrl + '/Api/Admin/CreateApplicationSettingXML', this.config_model).subscribe((res: Response) => {
        debugger
        console.log(res);
        this.router.navigateByUrl('employee');
      }, error => console.error(error));
    }
  }
}
