import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
import { SharingService } from '../sharing.service';
import { first } from 'rxjs/operators';
// Import the User model
import { User } from './../User';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})



export class LoginComponent implements OnInit {
  isTCAccepted: boolean;
  loginForm: FormGroup;
  // Property for the user
  private user: User;
  auditlog: { createdBy: string; createdDate: string; id: string; logType: string; nextValue: string; parentId: string; previousValue: string; ModuleName: string; }[];
  uname: string;
  Date: string;
  guid: string;
  Datelogs: string;
  submitted: any;
  f: any;
  dataNew: any;
  biomatricId: Object;
  // router: Router;

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

  }
  get username() { return this.loginForm.get('username'); }
  get password() { return this.loginForm.get('password'); }

  constructor(private http: HttpClient, private fb: FormBuilder, private router: Router, private myIndexService: SharingService) { }

  public onFormSubmit() {
    if (this.loginForm.valid) {
      this.user = this.loginForm.value;
      var id_name_model = {
        "userName": this.user.username, "passWord": this.user.password
      }
      this.myIndexService.tokenGet(id_name_model).pipe(first()).subscribe(data => {
        //debugger;
        if (data['tokenString'] != null) {
          this.dataNew = data;
          this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeId?username=' + id_name_model.userName).subscribe((res) => {
            this.biomatricId = res;
            // sessionStorage.setItem('biometrics', this.biomatricId['biometricId']);

            localStorage.setItem('currentUser', id_name_model.userName);
            localStorage.setItem('currentPassword', id_name_model.passWord);
            this.Datelogs = formatDate(new Date(), 'yyyy-mm-dd', 'en');
            //this.SharingDataService.MakeAuditLog(this.auditlog);
            this.router.navigate(['employee']);
          });
        }
        else {
          alert(data);
        }
      });
    }
  }
}


