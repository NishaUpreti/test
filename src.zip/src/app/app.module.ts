import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule, FormControl } from '@angular/forms';
import { EmployeeComponent } from './employee/employee.component';
import { LoginComponent } from './login/login.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainHeaderComponent } from './main-header/main-header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from './header/header.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { LeaveListComponent } from './leave-list/leave-list.component';
import { CommonStructureComponent } from './common-structure/common-structure.component';
import { FooterComponent } from './footer/footer.component';
import { NotificationBoxComponent } from './notification-box/notification-box.component';
import { PersonalinfoComponent } from './personalinfo/personalinfo.component';
import { EmpdetailComponent } from './empdetail/empdetail.component';
import { EducationdetailComponent } from './educationdetail/educationdetail.component';
import { PayrollinfoComponent } from './payrollinfo/payrollinfo.component';
import { OtherdetailComponent } from './otherdetail/otherdetail.component';
import { DocuploadComponent } from './docupload/docupload.component';
import { ChecklistComponent } from './checklist/checklist.component';
import { SharingService } from './sharing.service';
import { JwtInterceptor } from './JwtInterceptor';
import { LeaveRuleComponent } from './leave-rule/leave-rule.component';
import { AddEntitlementComponent } from './add-entitlement/add-entitlement.component';
import { InOutTimeComponent } from './in-out-time/in-out-time.component';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { ScrollSpyDirective } from './scroll-spy.directive';
import {
  MatInputModule, MatPaginatorModule, MatProgressSpinnerModule,
  MatSortModule, MatTableModule, MatCheckboxModule, MatSidenavModule, MatTooltipModule, MatToolbarModule, MatIconModule, MatListModule, MatRadioModule, MatTabsModule, MatFormFieldModule, MatSelectModule
} from "@angular/material";
import { MatStepperModule } from '@angular/material/stepper';

import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { AddLeaveRuleComponent } from './add-leave-rule/add-leave-rule.component';
import { EditLeaveRuleComponent } from './edit-leave-rule/edit-leave-rule.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { BasicEmpComponent } from './basic-emp/basic-emp.component';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { ValidationcompComponent } from './validationcomp/validationcomp.component';
import { TimecompComponent } from './timecomp/timecomp.component';
import { LeaveLogsComponent } from './leave-logs/leave-logs.component';
import { EditLeaveEntitlementComponent } from './edit-leave-entitlement/edit-leave-entitlement.component';
import { LeaveEntitlementListComponent } from './leave-entitlement-list/leave-entitlement-list.component';
import { TeamLeaveListComponent } from './team-leave-list/team-leave-list.component';
import { CompltLeaveReqListComponent } from './complt-leave-req-list/complt-leave-req-list.component';
import { CompleteEmpLeaveComponent } from './complete-emp-leave/complete-emp-leave.component';
import { AddRemarksComponent } from './add-remarks/add-remarks.component';
import { AddRemarksInnerComponent } from './add-remarks-inner/add-remarks-inner.component';
import { ConfigComponent } from './config/config.component';
import { MatDialogModule } from '@angular/material/dialog';
import { RolesAndRightsComponent } from './roles-and-rights/roles-and-rights.component';
import { AddNewRoleComponent } from './add-new-role/add-new-role.component';
import { AddActionComponent } from './add-action/add-action.component';
import { AddModuleComponent } from './add-module/add-module.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    LoginComponent,
    SidebarComponent,
    MainHeaderComponent,
    HeaderComponent,
    AddemployeeComponent,
    LeaveListComponent,
    CommonStructureComponent,
    FooterComponent,
    NotificationBoxComponent,
    PersonalinfoComponent,
    EmpdetailComponent,
    EducationdetailComponent,
    PayrollinfoComponent,
    OtherdetailComponent,
    DocuploadComponent,
    ChecklistComponent,
    LeaveRuleComponent,
    AddEntitlementComponent,
    InOutTimeComponent,
    EmployeeProfileComponent,
    ApplyLeaveComponent,
    ScrollSpyDirective,
    AddLeaveRuleComponent,
    EditLeaveRuleComponent,
    BasicEmpComponent,
    ValidationcompComponent,
    TimecompComponent,
    LeaveLogsComponent,
    EditLeaveEntitlementComponent,
    LeaveEntitlementListComponent,
    BasicEmpComponent,
    TeamLeaveListComponent,
    CompltLeaveReqListComponent,
    CompleteEmpLeaveComponent,
    AddRemarksComponent,
    AddRemarksInnerComponent,
    ConfigComponent,
    RolesAndRightsComponent,
    AddNewRoleComponent,
    AddActionComponent,
    AddModuleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatProgressSpinnerModule,
    NgMultiSelectDropDownModule.forRoot(),
    MatCheckboxModule, MatSidenavModule, MatTooltipModule, MatToolbarModule, MatIconModule, MatListModule, MatRadioModule, MatTabsModule, MatFormFieldModule, MatSelectModule, MatStepperModule, MatDialogModule, FilterPipeModule

  ],
  entryComponents: [
    BasicEmpComponent
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
