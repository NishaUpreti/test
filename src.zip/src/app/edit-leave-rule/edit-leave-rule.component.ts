import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-leave-rule',
  templateUrl: './edit-leave-rule.component.html',
  styleUrls: ['./edit-leave-rule.component.css']
})
export class EditLeaveRuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
