import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditLeaveRuleComponent } from './edit-leave-rule.component';

describe('EditLeaveRuleComponent', () => {
  let component: EditLeaveRuleComponent;
  let fixture: ComponentFixture<EditLeaveRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditLeaveRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditLeaveRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
