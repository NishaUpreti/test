import { Component, OnInit } from '@angular/core';
declare function datetimeFunc(): any ;
declare function select2Func(): any ;

@Component({
  selector: 'app-edit-leave-entitlement',
  templateUrl: './edit-leave-entitlement.component.html',
  styleUrls: ['./edit-leave-entitlement.component.css']
})
export class EditLeaveEntitlementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit() {
    select2Func();
    datetimeFunc();
  }
}
