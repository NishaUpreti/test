import { Component, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BasicEmpComponent } from '../basic-emp/basic-emp.component';
import { PersonalinfoComponent } from '../personalinfo/personalinfo.component';
import { EmpdetailComponent } from '../empdetail/empdetail.component';
import { EducationdetailComponent } from '../educationdetail/educationdetail.component';
import { MatStepperModule } from '@angular/material/stepper';

declare function datetimeFunc(): any;
declare function select2Func(): any;
//import {MatFormFieldModule} from '@angular/material/form-field';
import { from } from 'rxjs';;
@Pipe({ name: '' })


@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})

export class AddemployeeComponent implements OnInit {
  biometricids: any;

  @ViewChild(BasicEmpComponent) child: BasicEmpComponent;
  @ViewChild(PersonalinfoComponent) child1: PersonalinfoComponent;
  @ViewChild(EmpdetailComponent) child2: EmpdetailComponent
  @ViewChild(EducationdetailComponent) child3: EducationdetailComponent
  constructor(private http: HttpClient, public SharingService: SharingService, public _formBuilder: FormBuilder, public matstepper: MatStepperModule) {
  }


  basicinfo_form: FormGroup;
  personalinfo_form: FormGroup;
  otherdetail_form: FormGroup;

  ngOnInit() {

  }

  emptabClick() {
    select2Func();
    datetimeFunc();
  }

  GeteditemployeeForm(editbioid) {
    this.child.GetFormdata(editbioid);
    this.child1.GetpersonalFormdata(editbioid);
    this.child2.GetempdetailFormdata(editbioid);
    this.child3.GeteducationdetailFormdata(editbioid);
  }



}
/**
Copyright 2018 Google LLC. All Rights Reserved. 
Use of this source code is governed by an MIT-style license that can be found
in the LICENSE file at http://material.angularjs.org/HEAD/license.
**/
