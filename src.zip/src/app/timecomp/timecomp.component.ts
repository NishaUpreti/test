import { Component, OnInit, ViewChild } from '@angular/core';
import { ValidationcompComponent } from '../validationcomp/validationcomp.component';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { SharingService } from '../sharing.service';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-timecomp',
  templateUrl: './timecomp.component.html',
  styleUrls: ['./timecomp.component.css']
})
export class TimecompComponent implements OnInit {

  displayedColumnsSearch: string[] = ['selectSearch', 'employeeIdSearch', 'punchIdSearch', 'FirstNameSearch', 'middleNameSearch', 'lastNameSearch', 'userNameSearch', 'GenderSearch', 'PANCardNoSearch', 'PermanentHouseNoSearch', 'PermanentHouseNameSearch', 'PermanentStreetSearch', 'PermanentCountrySearch', 'PermanentStateSearch', 'PermanentCitySearch', 'PresentHouseNoSearch', 'PresentHouseNameSearch', 'PresentStreetSearch', 'PresentCountrySearch', 'PresentStateSearch', 'PresentCitySearch', 'MobileNoSearch', 'AlternateMobileNoSearch', 'EmailIDSearch', 'AlternateEmailIDSearch', 'WorkingEmailSearch', 'DesignationSearch', 'JoiningDateSearch', 'ReportToSearch', 'CompanySearch', 'BranchLocationSearch', 'DepartmentSearch', 'DivisionSearch', 'AssignedRoleSearch', 'EmploymentStatusSearch', 'EmploymentTypeSearch', 'MaritalStatusSearch', 'AadharCardNumberSearch', 'PassportNumberSearch', 'PassportValiditySearch', 'PhysicalChallengedSearch', 'FamilyPersonSearch', 'RelationSearch', 'ContactNoSearch', 'PANNoSearch', 'CTCSearch', 'BankAccountSearch'];
  dataSource = new MatTableDataSource;
  selection = new SelectionModel;
  displayedColumns: string[];
  timerulelist: any;
  timeid: string;
  timerulebyid: Object;
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private http: HttpClient, private router: Router, public SharingService: SharingService, public _formBuilder: FormBuilder) { }

  @ViewChild(ValidationcompComponent) child: ValidationcompComponent;
  ngOnInit() {
    console.log('componentinitialize');
    this.http.get(environment.baseUrl + '/api/Time/GetTimeRuleList')
      .subscribe(result => {
        this.timerulelist = result;
        console.log(this.timerulelist[0].timeRuleId);
        this.http.get(environment.baseUrl + '/api/Time/GetTimeRuleById?timeRuleId=' + this.timerulelist[0].timeRuleId).subscribe(result => {
          this.timerulebyid = result;
          console.log(this.timerulebyid);
        }, error => console.error(error));
      });

    //this.getTimeRule();

  }
  showtimeruledetail(timeroleidchk) {
    this.http.get(environment.baseUrl + '/api/Time/GetTimeRuleById?timeRuleId=' + timeroleidchk).subscribe(result => {
      this.timerulebyid = result;
    }, error => console.error(error));

  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  ShowAddTimeRule() {
    this.child.ngOnInit();
  }
  ShowEditTimeRule() {
    console.log('action trigger');
    this.child.ngOnInit();
  }
}

