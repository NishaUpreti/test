import {SelectionModel} from '@angular/cdk/collections';
import { environment } from 'src/environments/environment';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { formatDate } from '@angular/common';
import { CompltLeaveReqListComponent } from '../complt-leave-req-list/complt-leave-req-list.component';
import { AddRemarksComponent } from '../add-remarks/add-remarks.component';
declare var jquery: any;
declare var $: any;


@Component({
  selector: 'app-team-leave-list',
  templateUrl: './team-leave-list.component.html',
  styleUrls: ['./team-leave-list.component.css']
})

export class TeamLeaveListComponent implements OnInit {

  @Input() TeamleaveStatusId;
  
  
  biometrics: string;
  currentYear: any;
  currentYearFrom: string;
  currentYearTo: string;
  updateLeaveStatusModel: [{
    "leaveGroupId": string;
    "requestId": string;
    "LeaveDate": string;
		"biometricId": string;
		"remarks": string;
		"leaveStatusId": number;
		"modifiedBy": string;
    "deleted": string;
    "All": number;
    "Duration": string
  }]; 

  displayedColumns: string[] = ['select', 'sNo', 'leaveStatus', 'ManagerName', 'EmployeeName', 'NoOfDays', 'Duration','leaveGroupId', 'LeaveStatusId'];
  
  displayedColumnsSearch: string[] = ['selectSearch', 'sNoSearch', 'leaveStatusSearch', 'ManagerNameSearch', 'EmployeeNameSearch', 'NoOfDaysSearch', 'DurationSearch', 'leaveGroupIdSearch', 'LeaveStatusIdSearch'];

  fleetData:any = [];
  dataSource = new MatTableDataSource(this.fleetData);
  selection = new SelectionModel(this.fleetData);
  //leaveStatus: any;
  //defaultStatus: any;
  leaveGrpId: string;
  leaveId: any;
  leaveDate: any;
  grpIdFullView: any;
  compltLeaveList: boolean;
  addRemarks: boolean;

   /** Whether the number of selected elements matches the total number of rows. */
   isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
        this.selection.clear() :
        this.dataSource.data.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.sNo + 1}`;
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  @ViewChild(CompltLeaveReqListComponent) child:CompltLeaveReqListComponent;
  @ViewChild(AddRemarksComponent) child1:AddRemarksComponent;
  
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults 
    this.dataSource.filter = filterValue;
  }
  constructor(private http: HttpClient) {
    debugger;
    this.biometrics= sessionStorage.getItem('biometrics');
    this.currentYear = (new Date()).getFullYear();
    this.currentYearFrom = this.currentYear + '-01-01';
    this.currentYearTo = this.currentYear + '-12-31';
    this.getLeaveList();
   }

   sNoFilter = new FormControl('');
  empNameFilter = new FormControl('');
  dateAbsFilter = new FormControl('');
  totalDayFilter = new FormControl('');
  durationFilter = new FormControl('');
  leaveTypeFilter = new FormControl('');
  leaveStatusFilter = new FormControl('');
  descriptionFilter = new FormControl('');
  modifiedByFilter = new FormControl('');
  modifiedDateFilter = new FormControl('');
  appliedDateFilter = new FormControl('');
  fromDateFilter = new FormControl('');
  toDateFilter = new FormControl('');
  attachmentsFilter = new FormControl('');
  empIdFilter = new FormControl('');
  leavePlanFilter = new FormControl('');
  fromHoursFilter = new FormControl('');
  toHoursFilter = new FormControl('');
  totalHoursFilter = new FormControl('');

  ngOnInit() {
    this.compltLeaveList = false;
    this.addRemarks = false;
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    //this.defaultStatus = "Pending";
   }
  getLeaveList(){
    debugger;
    this.http.get(environment.baseUrl + '/api/Leave/GetEmployeeLeaveRequestList?biometricId=' + this.biometrics + '&' + 'FromDate=' + this.currentYearFrom + '&' + 'ToDate=' + this.currentYearTo).subscribe((res: any) => {
      console.log(res);
      this.fleetData = res;
      this.dataSource.data = this.fleetData;
    });
  }
  changeStatus(event, id, groupId, date): void{
    debugger;
    this.leaveId = id;
    this.leaveGrpId = groupId;
    this.leaveDate = date;
    //this.leaveStatus = event.currentTarget.innerText.trim();
    //this.defaultStatus = this.leaveStatus;
    this.updateLeaveStatus(); 
  }
  ChangecompltLeaveList(booleanData){
    this.compltLeaveList = booleanData;
   }
  openFullView(grpId){
    debugger;
    this.grpIdFullView = grpId;
    this.compltLeaveList = true;
    if(this.child){
      this.child.ngOnInit();
    }
  }
  addRemarksModal(){
    debugger;
    this.addRemarks = true;
    if(this.child1){
      this.child1.ngOnInit();
    }
  }
  ChangeaddRemarks(addRemarksData){
    this.addRemarks = addRemarksData;
  }
  updateLeaveStatus(){
    debugger;

    this.updateLeaveStatusModel = [{
      "leaveGroupId": this.leaveGrpId,
      "requestId": null,
      "LeaveDate": null,
      "biometricId": this.biometrics,
      "remarks": "test",
      "leaveStatusId": this.leaveId,
      "modifiedBy": this.biometrics,
      "deleted": "0",
      "All": 1,
      "Duration": this.leaveDate

    }];
    console.log(this.updateLeaveStatusModel);
    this.http.post(environment.baseUrl + '/api/Leave/UpdateLeaveStatus', this.updateLeaveStatusModel).subscribe((res:Response) => {
      debugger;
      alert("Leave status Updated");
      console.log("Leave status Updated");
      console.log(res);
      this.getLeaveList();
    })
  }
 
  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
