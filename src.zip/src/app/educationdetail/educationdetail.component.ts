import * as core from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { formatDate } from '@angular/common';
@core.Component({
  selector: 'app-educationdetail',
  templateUrl: './educationdetail.component.html',
  styleUrls: ['./educationdetail.component.css']
})
export class EducationdetailComponent implements core.OnInit {
  education_form: FormGroup;
  education_formmodel: any;
  university: string;
  college: string;
  startyear: any;
  endyear: any;
  course: any;
  Date: any;
  Datelogs: any;
  uname: any;
  type: any;
  branchName: any;
  submitted = false;
  personal: {};
  coursedata: any;
  EmployeeCompleteDetailsViewModel: { "personal": {}; "employement": {}; "qualification": {}; "target": {}; "incentive": {};"payroll":{},"document":{} }

  qualifications: {"biometricId": string; "universityName": string; "collegeName": string; "startYear": string; "endYear": string; "branchName": string; "createdDate": string; "modifiedDate": string; "createdBy":string; "modifiedBy":string; "deleted": string;}
  allqualifi: [];
  qualificationdata=[];
  courseList: Object;
  educhnge: any;
  empType: Object;  
  edutypelist: Object;
  edutypedata: Object;
  biometrics: string;
  qualificationsies: { "biometricId": string; "universityName": any; "collegeName": any; "startYear": any; "endYear": any; "branchName": any; "createdDate": any; "modifiedDate": any; "createdBy": string; "modifiedBy": string; "deleted": string; };
  biometricids: any;
  constructor(private http: HttpClient, public formBuilder: FormBuilder, public SharingService: SharingService) { }

  ngOnInit() {
    this.education_form = this.formBuilder.group({
      university: ['', Validators.required],
      college: ['', Validators.required],
      startyear: ['', Validators.required],
      endyear: ['', Validators.required],
      course: ['', Validators.required],
      Specialization:['']
    });
    this.uname = localStorage.getItem('currentUser');
    console.log(this.uname);
    this.Date = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.http.get(environment.baseUrl + '/api/Master/GetEducationTypeList').subscribe(result => {
      this.edutypelist = result;
      console.log(this.edutypelist);
    }, error => console.error(error));
  }
  get f() { return this.education_form.controls; }

  onedutypeSelect(eduevent) {
    this.educhnge = eduevent.target.value;
    this.http.get(environment.baseUrl + '/api/Master/GetCourseList?EducationTypeId=' + this.educhnge).subscribe(result => {
      this.coursedata = result;
      console.log(this.coursedata);
    }, error => console.error(error));

  }
  onSubmit() {
  this.submitted =true
  if (!this.education_form.valid) {
    return false;
} else if(this.education_form.valid){     
  if(this.EmployeeCompleteDetailsViewModel==undefined){
    // this.frmeDatess= $("#frmdates").val();
    // this.toDatess= $("#todates").val(); 
    this.qualificationsies = {
      "biometricId": localStorage.getItem('addempbiometrics'),
      "universityName": this.education_form.value.university,
      "collegeName": this.education_form.value.college,
      "startYear": this.education_form.value.startyear,
      "endYear": this.education_form.value.endyear,
      "branchName": this.education_form.value.Specialization,
      "createdDate": this.Datelogs,
      "modifiedDate": this.Datelogs,
      "createdBy":sessionStorage.getItem('biometrics'),
      "modifiedBy":sessionStorage.getItem('biometrics'),
      "deleted": "0"
    }

    this.qualificationdata.push(this.qualificationsies);
    this.EmployeeCompleteDetailsViewModel = {
      "personal":{},
      "employement":[],
      "qualification":this.qualificationdata,
      "target":{},
      "incentive":{},
      "payroll":null,
      "document":[]
    }

    this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo',this.EmployeeCompleteDetailsViewModel).subscribe((res: Response) => {
      this.education_form.reset();
    }, error => console.error(error));
  }
  else {
    this.http.post(environment.baseUrl+'/api/EIM/InsertUpdateEmployeeOtherInfo',this.EmployeeCompleteDetailsViewModel).subscribe((res: Response) => {
      console.log(res);
      this.education_form.reset();
    }, error => console.error(error));
  }
  
}
 
  }

  GeteducationdetailFormdata(editbioid){
    this.biometricids = editbioid;
    console.log(this.biometricids);
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeInfoByBiometricId?biomatricId=' + this.biometricids).subscribe((res: any) => {
      console.log("edit employee Rule");
      console.log(res);
      this.education_form.setValue({
      //  biometricId: localStorage.getItem('addempbiometrics'),
        university: res.qualification.universityName,
        college: res.qualification.collegeName,
        startyear: res.qualification.startyear,
        endyear :res.qualification.endYear,
        Specialization: res.qualification.branchName,
        createdDate: res.qualification.createdDate,
        modifiedDate: this.Datelogs,
        createdBy:sessionStorage.getItem('biometrics'),
        modifiedBy:sessionStorage.getItem('biometrics'),
        deleted: "0"
      });
    });

  }

  addqualification() {
    this.qualifications = {
      "biometricId": localStorage.getItem('addempbiometrics'),
      "universityName": this.education_form.value.university,
      "collegeName": this.education_form.value.college,
      "startYear": this.education_form.value.startyear,
      "endYear": this.education_form.value.endyear,
      "branchName": this.education_form.value.Specialization,
      "createdDate": this.Datelogs,
      "modifiedDate": this.Datelogs,
      "createdBy":sessionStorage.getItem('biometrics'),
      "modifiedBy":sessionStorage.getItem('biometrics'),
      "deleted": "0"
    }

    this.qualificationdata.push(this.qualifications);
    this.EmployeeCompleteDetailsViewModel = {
      "personal": {},
      "employement": [],
      "qualification": this.qualificationdata,
      "target": {},
      "incentive": {},
      "payroll":{},
      "document":[] 
    }
    this.education_form.reset();
  }



}
