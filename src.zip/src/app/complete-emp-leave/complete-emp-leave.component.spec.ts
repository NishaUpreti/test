import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteEmpLeaveComponent } from './complete-emp-leave.component';

describe('CompleteEmpLeaveComponent', () => {
  let component: CompleteEmpLeaveComponent;
  let fixture: ComponentFixture<CompleteEmpLeaveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteEmpLeaveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteEmpLeaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
