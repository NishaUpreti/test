import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-add-remarks',
  templateUrl: './add-remarks.component.html',
  styleUrls: ['./add-remarks.component.css']
})
export class AddRemarksComponent implements OnInit {
  
  
  @Input() addRemarks: boolean;
  @Output() addRemarksChange = new EventEmitter<boolean>();
  constructor() { debugger;}
 
  
  ngOnInit() {
    debugger;
    if(this.addRemarks){
      $('#addRemarks').modal('show'); 
    }
  }
  closeAddRemarks(){
    if(this.addRemarks){
      $('#addRemarks').modal('hide'); 
      this.addRemarks = false;
      this.addRemarksChange.emit(this.addRemarks);
    }
   }
}
