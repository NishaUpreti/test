export class User {

    id: number;
    username: string;
    password: string;

    constructor(values: Object = {}) {
      // Constructor initialization
      Object.assign(this, values);
  }

}
