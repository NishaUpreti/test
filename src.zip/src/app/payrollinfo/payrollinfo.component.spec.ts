import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrollinfoComponent } from './payrollinfo.component';

describe('PayrollinfoComponent', () => {
  let component: PayrollinfoComponent;
  let fixture: ComponentFixture<PayrollinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrollinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrollinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
