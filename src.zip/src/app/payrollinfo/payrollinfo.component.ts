import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payrollinfo',
  templateUrl: './payrollinfo.component.html',
  styleUrls: ['./payrollinfo.component.css']
})
export class PayrollinfoComponent implements OnInit {
  payrollinfo_form: FormGroup;
  submitted = false;
  biometrics: string;
  payrollinfo: { "personal": {}; "employement": any[]; "qualification": any[]; "target": any; "incentive": any; "payroll": {};"document":any[]; };
  Datelogs: string;
  biometricId: string;
  payrollinfomodal: {};
  constructor(private http: HttpClient, private router: Router, public SharingService: SharingService, public _formBuilder: FormBuilder) { }

  ngOnInit() {
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.payrollinfo_form = this._formBuilder.group({
      pan: ['', Validators.required],
      ctc: ['', Validators.required],
      esino: ['', Validators.required],
      ESIDispensary: ['', Validators.required],
      pfno: ['', Validators.required],
      payrollrule: [''],
      bankdetail: [''],
      branch: [''],
      IFSCode: ['', Validators.required],
      bankaccount: ['', Validators.required],
      accountholdername: ['', Validators.required],
      ShiftType: [''],
      TimeZone: [''],
      LeaveRule: ['']
    });
  }
  get f() { return this.payrollinfo_form.controls; }
  onSubmit() {
  //   this.biometrics = localStorage.getItem('biometrics');
    this.payrollinfomodal = {
    "biometricId": localStorage.getItem('addempbiometrics'),
    "panNo":  this.payrollinfo_form.value.pan,
    "pfNo":  this.payrollinfo_form.value.pfno,
    "esicNo":  this.payrollinfo_form.value.esino,
    "esicDispensary":  this.payrollinfo_form.value.ESIDispensary,
    "ctc": this.payrollinfo_form.value.ctc,
    "paygroupId": localStorage.getItem('addempbiometrics'),
    "bankId": this.payrollinfo_form.value.bankdetail,
    "bankAccountNo": this.payrollinfo_form.value.bankaccount,
    "bankAccountHolderName": this.payrollinfo_form.value.accountholdername,
    "deleted": 0,
    "createdBy": sessionStorage.getItem('biometrics'),
    "createdDate": this.Datelogs,
    "modifiedBy": sessionStorage.getItem('biometrics'),
    "modifiedDate": this.Datelogs
     }

    this.payrollinfo = {
      "personal": {},
      "employement": [],
      "qualification": [],
      "target": {},
      "incentive": {},
      "payroll": this.payrollinfomodal,
      "document":[]
    }
    this.submitted = true;

    // stop here if form is invalid
    if (this.payrollinfo_form.invalid) {
      return false;
    }
    else if (!this.payrollinfo_form.invalid) {
      this.http.post(environment.baseUrl + '/api/EIM/InsertUpdateEmployeeOtherInfo', this.payrollinfo).subscribe((res: Response) => {
        console.log(res);
      })
    }

   }
}
