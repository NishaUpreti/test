import { Component, OnInit, ViewChild } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BasicEmpComponent } from '../basic-emp/basic-emp.component';
// import { PersonalinfoComponent } from '../personalinfo/personalinfo.component';
// import { EmpdetailComponent } from '../empdetail/empdetail.component';
// import { EducationdetailComponent } from '../educationdetail/educationdetail.component';
// import { PayrollinfoComponent } from '../payrollinfo/payrollinfo.component';
// import { OtherdetailComponent } from '../otherdetail/otherdetail.component';
// import { DocuploadComponent } from '../docupload/docupload.component';

// import { BasicEmpComponent } from '../basic-emp/basic-emp.component';
@Component({
  selector: 'app-employee-profile',
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.css']
})
export class EmployeeProfileComponent implements OnInit {
  currentSection = 'section1';
  employeeid: any;
  bioid: string;
  isbasicInfoEdit: boolean;
  ispersonalinfo: boolean;
  ispersonalinfoEdit: boolean;
  ispersonalinfoedit: boolean;
  isbasic_empedit: boolean;
  isempdetail: boolean;
  empdetailcrd: boolean;
  isedudetailedit: boolean;
  edudetailcrd: boolean;
  payinfocrd: boolean;
  ispayinfocrdedit: boolean;
  isotherinfocrd: boolean;
  isotherinfocrdedit: boolean;
  documentcrd: boolean;
  isdocumentcrdedit: boolean;
  onSectionChange(sectionId: string) {
    this.currentSection = sectionId;
  }

  scrollTo(section) {
    document.querySelector('#' + section)
      .scrollIntoView();
  }
  constructor(private http: HttpClient, private router: Router) { }
  @ViewChild(BasicEmpComponent) childBasic: BasicEmpComponent;
  // @ViewChild(PersonalinfoComponent) childpersonalinfo: PersonalinfoComponent;
  // @ViewChild(EmpdetailComponent) childEmpdetail: EmpdetailComponent;
  // @ViewChild(EducationdetailComponent) childEducationdetail: EducationdetailComponent;
  // @ViewChild(PayrollinfoComponent) childpayinfocrd: PayrollinfoComponent;
  // @ViewChild(OtherdetailComponent) childOtherdetail: OtherdetailComponent;
  // @ViewChild(DocuploadComponent) childdocumentcrd: DocuploadComponent;
  ngOnInit() {
    this.empdetailcrd = true;
    this.isbasicInfoEdit = true;
    this.isbasic_empedit = false;
    this.ispersonalinfo = true;
    this.ispersonalinfoedit = false;
    this.isempdetail = false;
    this.isedudetailedit = false;
    this.edudetailcrd = true;
    this.payinfocrd = true;
    this.ispayinfocrdedit = false;
    this.isotherinfocrd = true;
    this.isotherinfocrdedit = false;
    this.documentcrd = true;
    this.isdocumentcrdedit = false;
    this.bioid = localStorage.getItem('empbiometric');
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeInfoByBiometricId?biomatricId=' + this.bioid).subscribe(result => {
      this.employeeid = result;
      console.log(this.employeeid);
    }, error => console.error(error));

    //this.child.savendnext = false;
    ////this.child.isupdate = true;
  }
  BasicEdit() {
    alert();
    debugger
    //this.childBasic.ngOnInit();
    this.isbasicInfoEdit = false;
    this.isbasic_empedit = true;
    // this.child.savendnext = false;
    // this.child.isupdate = true;
  }
  personalinfoEdit() {
    debugger
    // this.childpersonalinfo.ngOnInit();
    // this.ispersonalinfoEdit = true;
    // this.ispersonalinfo = false;
    // this.ispersonalinfoedit = true;
  }
  empdetailedit() {
    // this.childEmpdetail.ngOnInit();
    // this.isempdetail = true;
    // this.empdetailcrd = false;
  }
  edudetailedit() {
    // this.childEducationdetail.ngOnInit();
    // this.isedudetailedit = true;
    // this.edudetailcrd = false;
  }
  payinfocrdedit() {
    //this.childpayinfocrd.ngOnInit();
    // this.payinfocrd = false;
    // this.ispayinfocrdedit = true;
  }
  otherinfocrdedit() {
    //this.childOtherdetail.ngOnInit();
    // this.isotherinfocrd = false;
    // this.isotherinfocrdedit = true;
  }
  documentcrdedit() {
    //this.childdocumentcrd.ngOnInit();
    // this.documentcrd = false;
    // this.isdocumentcrdedit = true;
  }
  // empProfile(empbiometric) {

  //   //this.router.navigate(['employee-profile']);

  // }

}
