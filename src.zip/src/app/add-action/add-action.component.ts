import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { AddModuleComponent } from '../add-module/add-module.component';
declare var $: any;
@Component({
  selector: 'app-add-action',
  templateUrl: './add-action.component.html',
  styleUrls: ['./add-action.component.css']
})
export class AddActionComponent implements OnInit {
  constructor() { }
  @ViewChild(AddModuleComponent) child: AddModuleComponent;
  @Output() actionEvent = new EventEmitter<string>();
  actioncancel() {
    this.actionEvent.emit();
  }
  modulecancelsuccess($event) {
    $('#addmodule').modal('hide');
    $('#add_action').modal('show');
  }
  ngOnInit() {
  }
  addmodel() {
    this.child.ngOnInit();
  }
}
