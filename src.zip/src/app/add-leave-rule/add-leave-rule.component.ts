import { Component, OnInit, EventEmitter, Output  } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { AddLeaveRuleModel } from '../model/add-leave-rule-model';
import {formatDate} from '@angular/common';
declare function datetimeFunc(): any ;
declare function select2Func(): any ;


@Component({
  selector: 'app-add-leave-rule',
  templateUrl: './add-leave-rule.component.html',
  styleUrls: ['./add-leave-rule.component.css']
})
export class AddLeaveRuleComponent implements OnInit {

  @Output() getLeaveRuleEvent = new EventEmitter<string>();

  callParent(): void {
    this.getLeaveRuleEvent.next();
  }

  addLeaveForm: FormGroup;
  actionButton;
  addNewLeaveForm: FormGroup;
  private AddLeaveRuleModels: AddLeaveRuleModel;
  submitted = false;
  newRulesubmitted = false;
  leaveRuleMain: boolean;
  newLeaveTypeSec: any;
  selectedLink: string;
  leaveExhSec: boolean;
  backDayHourSec: boolean;
  extraLeaveSec: boolean;
  CFAlloSec: boolean;
  leaveTypeList: Response;
  newLeaveModel: { "name": string; "description": string, "createdBy": string, "modifiedBy": string, "createdDate": string, "modifiedDate": string};
  todayDate: any;
  leaveRuleName: any;
  ShowFilter = true;
  limitSelection = false;
  ApplicableFor: {};
  selectedItems: any[] = [];
  newselectedItems: any[] = [];
  dropdownSettings: any = {};
  exhaustLeaveDedTypeId: any;
  CfLeaveType: any;
  isEncashApplicable: any;
  defLeaveDeductn: any;
  carryForwardDur: any;
  leaveRuleId: any;

  constructor(private http: HttpClient, public formBuilder: FormBuilder) { }

  ngOnInit() {
    this.leaveRuleMain = true;
    this.newLeaveTypeSec = false;
    this.selectedLink = "days"; 
    this.leaveExhSec =  false;
    this.backDayHourSec = false;
    this.extraLeaveSec = true;
    this.CFAlloSec = true;

    this.addLeaveForm=this.formBuilder.group({
      leaveRuleName: ['', Validators.required],
      allocationDur:['',Validators.required],
      ruleDescription:[],
      allocationType: ['days'],
      allocatedLeaves: [],
      employeeType: [this.selectedItems],
      carryForward: [1],
      isbackDatedApplicable: [0],
      carryForwardLeaveTypeId: [],
      isEncashApp: [],
      isExtraLeaveConsumedDed: [1],
      extraLeaveConsumed: [],
      extraLeaveConsumedDed: [],
      carryForwardDur: [],
      exhaustLeaveDed: [],
      noOfBackDaysAllowed: []
    });
    this.addNewLeaveForm = this.formBuilder.group({
      newLeaveType:['', Validators.required],
      descriptionNew:['', Validators.required]
    });
    this.todayDate = formatDate(new Date(), 'yyyy/MM/dd', 'en');
    this.getLeaveType();
    
    this.getEmployeeType();
    
      this.selectedItems = [];
      this.dropdownSettings = {
          singleSelection: false,
          idField: "id",
          textField: "EmploymentType",
          selectAllText: 'Select All',
          unSelectAllText: 'UnSelect All',
          itemsShowLimit: 2,
          allowSearchFilter: this.ShowFilter
      };
      
  }

  get f() { return this.addLeaveForm.controls; }
  get fNew() { return this.addNewLeaveForm.controls; }
  
  GeteditleaveRuleForm(leaveRuleId){
    debugger;
    this.leaveRuleId = leaveRuleId;
    this.http.get(environment.baseUrl + '/api/Leave/GetLeaveRuleById?LeaveRuleId=' + this.leaveRuleId).subscribe((res: any) => {
      debugger;
      console.log("edit leave Rule");
      console.log(res);
      this.addLeaveForm.setValue({
        leaveRuleName: res.leaveRuleName,
        ruleDescription: res.ruleDescription,
        allocationDur: res.allocationDur, 
        leaveTypeId: res.leaveTypeId,
        allocationType: res.allocationType,
        allocatedLeaves: res.allocatedLeaves,
        carryForward: res.carryForward,
        carryForwardDur: res.carryForwardDur,
        carryForwardLeaveTypeId: res.carryForwardLeaveTypeId,
        isEncashApp: res.isEncashApp,
        isbackDatedApplicable: res.isbackDatedApplicable,
        noOfBackDaysAllowed: res.noOfBackDaysAllowed,
        exhaustLeaveDedTypeId: res.exhaustLeaveDedTypeId,
        exhaustLeaveDed: res.exhaustLeaveDed,
        isExtraLeaveConsumedDed: res.isExtraLeaveConsumedDed,
        extraLeaveConsumedDedDur: res.extraLeaveConsumedDedDur,
        extraLeaveConsumed: res.extraLeaveConsumed,
        extraLeaveConsumedDed: res.extraLeaveConsumedDed,
        leaveTypeIdForDedWithoutBal: res.leaveTypeIdForDedWithoutBal,
        employeeType: res.employeeType
      });
    });
  }
  onItemSelect(item: any) {
    //console.log('onItemSelect', item);
    this.selectedItems.push(item);
    this.newselectedItems = this.selectedItems.map(o => {
      return (o.id);
    });
    //console.log(this.newselectedItems);
  }
  onSelectAll(items: any) {
      //console.log('onSelectAll', items);
      this.selectedItems.push(items);
      this.newselectedItems = this.selectedItems.map(o => {
        return (o.id) ;
      });
      //console.log(this.newselectedItems);
  }
  toogleShowFilter() {
      this.ShowFilter = !this.ShowFilter;
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { allowSearchFilter: this.ShowFilter });
  }
  
  handleLimitSelection() {
      if (this.limitSelection) {
          this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
      } else {
          this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
      }
  }

  ngAfterViewInit(){
    select2Func();
    datetimeFunc();
  }

  getLeaveType(){
    this.http.get(environment.baseUrl + '/api/Master/GetLeaveTypeList').subscribe((res: Response) => {
      // console.log(res);
      this.leaveTypeList = res;
    });
  }
  getEmployeeType(){
    this.http.get(environment.baseUrl + '/api/Master/GetEmploymentTypeList').subscribe((res: Response) => {
       console.log(res);
      this.ApplicableFor = res;
    });
  }
  showLeaveType(){
    this.leaveRuleMain = false;
    this.newLeaveTypeSec = true;
  }
  // hideNewLave(){
  //   this.leaveRuleMain = true;
  //   this.newLeaveTypeSec = false;
  // }
  setradio(e: string): void   
  {  
    this.selectedLink = e;        
  } 
  isSelected(name: string): boolean   {
    return (this.selectedLink === name);
  } 
  
  setradioExhus(e: string): void   
  {   
    if(e==="yes"){
      this.leaveExhSec = true;
    }
    else
      this.leaveExhSec = false;
  }  
  setRadioBackD(e: string): void   
  {   
    if(e==="yes"){
      this.backDayHourSec = true;
    }
    else
      this.backDayHourSec = false;
  }
  setRadioCF(e: string): void{
    if(e==="no"){
      this.CFAlloSec = false;
    }
    else
      this.CFAlloSec = true;
  }
  setRadioExtLEave(e: string): void{
    if(e==="no"){
      this.extraLeaveSec = false;
    }
    else
      this.extraLeaveSec = true;
  }
  getSelectedleaveText(event: any): void{
    this.leaveRuleName = (<HTMLElement>event.target)['options']
      [(<HTMLElement>event.target)['options'].selectedIndex].text;
  }
  getleaveDeductFrom(event: any): void{
    this.exhaustLeaveDedTypeId = (<HTMLElement>event.target)['options']
      [(<HTMLElement>event.target)['options'].selectedIndex].value;
  }
  getCfLeaveType(event: any): void{
    this.CfLeaveType = (<HTMLElement>event.target)['options']
      [(<HTMLElement>event.target)['options'].selectedIndex].value;
  }
  getdefaultLeaveDed(event: any): void{
    this.defLeaveDeductn = (<HTMLElement>event.target)['options']
    [(<HTMLElement>event.target)['options'].selectedIndex].value;
  }
  getcarryForwardDur(event: any): void{
    this.carryForwardDur = (<HTMLElement>event.target)['options']
    [(<HTMLElement>event.target)['options'].selectedIndex].text;
  }
  leaveEncashed(event: any): void{
    this.isEncashApplicable = (<HTMLElement>event.target)['options']
      [(<HTMLElement>event.target)['options'].selectedIndex].value;
  }
  onSubmit(){
    this.submitted = true
    if(this.leaveRuleId == null){
      this.AddLeaveRuleModels={
        "id": null,
        "leaveRuleId": null,
        "leaveRuleName": this.leaveRuleName,
        "ruleDescription": this.addLeaveForm.value.ruleDescription,
        "allocationDur": this.addLeaveForm.value.allocationDur, 
        "leaveTypeId": parseInt( this.addLeaveForm.value.leaveRuleName),
        "allocationType": this.addLeaveForm.get('allocationType').value,
        "allocatedLeaves": this.addLeaveForm.value.allocatedLeaves,
        "carryForward": this.addLeaveForm.get('carryForward').value,
        "carryForwardDur": this.carryForwardDur,
        "carryForwardLeaveTypeId": parseInt(this.CfLeaveType) ,
        "isEncashApp": parseInt(this.isEncashApplicable),
        "isbackDatedApplicable": this.addLeaveForm.get('isbackDatedApplicable').value,
        "noOfBackDaysAllowed": this.addLeaveForm.value.noOfBackDaysAllowed,
        "exhaustLeaveDedTypeId": parseInt(this.exhaustLeaveDedTypeId),
        "exhaustLeaveDed": this.addLeaveForm.value.exhaustLeaveDed,
        "isExtraLeaveConsumedDed": this.addLeaveForm.get('isExtraLeaveConsumedDed').value,
        "extraLeaveConsumedDedDur": this.addLeaveForm.value.noOfBackDaysAllowed,
        "extraLeaveConsumed": this.addLeaveForm.value.extraLeaveConsumed,
        "extraLeaveConsumedDed": this.addLeaveForm.value.extraLeaveConsumedDed,
        "leaveTypeIdForDedWithoutBal": parseInt(this.defLeaveDeductn),
        "employeeType": this.newselectedItems,
        "createdBy": "",
        "createdDate": "2019-04-01T12:06:50.0153484+05:30",
        "modifiedBy": "",
        "modifiedDate": "2019-04-01T12:06:50.0153484+05:30",
        "deleted":0
      };
    }
    else if(this.leaveRuleId != null){
      this.AddLeaveRuleModels={
        "id": null,
        "leaveRuleId": this.leaveRuleId,
        "leaveRuleName": this.leaveRuleName,
        "ruleDescription": this.addLeaveForm.value.ruleDescription,
        "allocationDur": this.addLeaveForm.value.allocationDur, 
        "leaveTypeId": parseInt( this.addLeaveForm.value.leaveRuleName),
        "allocationType": this.addLeaveForm.get('allocationType').value,
        "allocatedLeaves": this.addLeaveForm.value.allocatedLeaves,
        "carryForward": this.addLeaveForm.get('carryForward').value,
        "carryForwardDur": this.carryForwardDur,
        "carryForwardLeaveTypeId": parseInt(this.CfLeaveType) ,
        "isEncashApp": parseInt(this.isEncashApplicable),
        "isbackDatedApplicable": this.addLeaveForm.get('isbackDatedApplicable').value,
        "noOfBackDaysAllowed": this.addLeaveForm.value.noOfBackDaysAllowed,
        "exhaustLeaveDedTypeId": parseInt(this.exhaustLeaveDedTypeId),
        "exhaustLeaveDed": this.addLeaveForm.value.exhaustLeaveDed,
        "isExtraLeaveConsumedDed": this.addLeaveForm.get('isExtraLeaveConsumedDed').value,
        "extraLeaveConsumedDedDur": this.addLeaveForm.value.noOfBackDaysAllowed,
        "extraLeaveConsumed": this.addLeaveForm.value.extraLeaveConsumed,
        "extraLeaveConsumedDed": this.addLeaveForm.value.extraLeaveConsumedDed,
        "leaveTypeIdForDedWithoutBal": parseInt(this.defLeaveDeductn),
        "employeeType": this.newselectedItems,
        "createdBy": "",
        "createdDate": "2019-04-01T12:06:50.0153484+05:30",
        "modifiedBy": "",
        "modifiedDate": "2019-04-01T12:06:50.0153484+05:30",
        "deleted":0
      };
    }
    if(this.addLeaveForm.valid){
      debugger;
      //console.log(this.AddLeaveRuleModels);
      this.http.post(environment.baseUrl + '/api/Leave/InsertUpdateLeaveRule', this.AddLeaveRuleModels).subscribe((res: Response) => {
        console.log(res);
        this.callParent();
        this.addLeaveForm.reset();
        this.submitted = false;
      });
    }
    // stop here if form is invalid
    else if (!this.addLeaveForm.valid) {
      return false;
    }
  }
 
  newLeaveSubmit(){
    debugger;
    this.newRulesubmitted = true

    this.newLeaveModel = {
        "name": this.addNewLeaveForm.value.newLeaveType,
        "description": this.addNewLeaveForm.value.descriptionsNew,
        "createdBy": "ad5610a8-02ff-4123-bc7d-9148d9ffbd20",
        "modifiedBy": "ad5610a8-02ff-4123-bc7d-9148d9ffbd20",
        "createdDate": this.todayDate,
        "modifiedDate": this.todayDate
    }
    // stop here if form is invalid
    if (!this.addNewLeaveForm.valid) {
      return false;
    } else if(this.addNewLeaveForm.valid){
      this.http.post(environment.baseUrl + '/api/Leave/InsertUpdateLeaveType', this.newLeaveModel).subscribe((res: Response) => {
        // console.log("new Leave Rule");
        // console.log(res);
        alert(res);
        this.addNewLeaveForm.reset();
        this.newRulesubmitted = false;
        this.getLeaveType();
        this.leaveRuleMain = true;
        this.newLeaveTypeSec = false;

      });
    }

  }

}
