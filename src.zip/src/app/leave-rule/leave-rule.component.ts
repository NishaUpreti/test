import {SelectionModel} from '@angular/cdk/collections';
import { Component, OnInit, ViewChild} from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { AddLeaveRuleComponent } from '../add-leave-rule/add-leave-rule.component';

declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-leave-rule',
  templateUrl: './leave-rule.component.html',
  styleUrls: ['./leave-rule.component.css']
})
export class LeaveRuleComponent implements OnInit {
  leaveRuleMain: boolean;
  deleteLeaveRuleId: any;
  newLeaveTypeSec: boolean;
  leaveRuleList: any;
  delLeaveRuleModel: {
    "leaveRuleId": string,
    "deleted": number,
    "modifiedBy": string,
    "modifiedDate": string
  }

  constructor(private http: HttpClient) { }
  getLeaveRule(){
    this.http.get(environment.baseUrl + '/api/Leave/GetLeaveRuleList').subscribe((res: any) => {
      console.log("Get Leave Rule List.");
      console.log(res);
      this.leaveRuleList = res;
    });
  }

  
  deleteLeaveRuleFun(leaveRuleId){
    $('#deleteLeaveRule').modal('show');
    this.deleteLeaveRuleId = leaveRuleId;
  }
  ConfirmDelLeaveRule(leaveRuleId){
    debugger;
    this.delLeaveRuleModel = {
      "leaveRuleId": leaveRuleId,
      "deleted": 1,
      "modifiedBy": "sample string 2",
      "modifiedDate": "2019-04-13T10:33:39.0575577+05:30"
    }
    console.log(this.delLeaveRuleModel);
    this.http.put(environment.baseUrl + '/api/Leave/DeleteLeaveRule', this.delLeaveRuleModel).subscribe((res: any) => {
      alert(res);
      //console.log(res);
      this.getLeaveRule();
      $('#deleteLeaveRule').modal('hide');
    });
  }
  ngOnInit() {
    this.getLeaveRule();
    this.loadScript('../assets/js/leaveRule.js'); 
  }
  
  
  @ViewChild(AddLeaveRuleComponent) child:AddLeaveRuleComponent;


  ShowAddLeaveRule(){
    debugger;
    this.child.ngOnInit();
  }
  editLeaveRule(leaveRuleId){
    debugger;
    this.child.GeteditleaveRuleForm(leaveRuleId);
  }

  public loadScript(url: string) {
    const body = <HTMLDivElement> document.body;
    const script = document.createElement('script');
    script.innerHTML = '';
    script.src = url;
    script.async = false;
    script.defer = true;
    body.appendChild(script);
  }
}
