import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { formatDate } from '@angular/common';
import { TimeRuleModel } from '../model/timerule.model'


@Component({
  selector: 'app-validationcomp',
  templateUrl: './validationcomp.component.html',
  styleUrls: ['./validationcomp.component.css']
})
export class ValidationcompComponent implements OnInit {
  //@Output() nameEvent = new EventEmitter<string>();
  // addtimeruleModel: {}
  addtimeruleform: FormGroup;
  submitted = false;
  registerForm: FormGroup;
  LateExemption: boolean;
  LateExemptionafter: boolean;
  sortleave: boolean;
  extraworking: boolean;
  extraworkWeekoff: boolean;
  constraint: boolean;
  lunchtimefn: boolean;
  exitimediv: boolean;
  ShowFilter = false;
  limitSelection = false;
  weekoffdays: any[] = [];
  dropdownSettings: any = {};
  selectedItems: any[] = [];
  weekoffdaysalternate: any[] = [];
  timerulelist: object;
  Datelogs: string;
  Date: string;
  weekoffdaystype: any[] = [];
  isAddtimerule: boolean;
  weekoffdaystypelist: [];
  defaultOpen: boolean;

  // TimeRuleModel: {};

  public TimeRuleModel: TimeRuleModel;
  adddate: {};
  timeid: string;
  timerulebyid: Object;
  gtd: any;
  weekoffdaysSelect: any;



  constructor(private http: HttpClient, public formBuilder: FormBuilder) { }


  ngOnInit() {

    let acb: [];

    this.defaultOpen = false;
    this.Date = formatDate(new Date(), 'mm-dd-yyyy', 'en');
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.addtimeruleform = this.formBuilder.group({
      timeruletitle: ['', Validators.required],
      ApplicableTimeZone: ['', Validators.required],
      MorningPunchfrom: ['', Validators.required],
      MorningPunchto: ['', Validators.required],
      EntryRelaxation: [''],
      RelaxationOn: [''],
      RelaxationOnNo: [''],
      AfternoonEntryFrom: ['', Validators.required],
      AfternoonEntryTo: ['', Validators.required],
      AfternoonRelaxation: [''],
      AfternoonRelaxationOn: [''],
      AfternoonRelaxationNo: [''],
      fulldayhours: ['', Validators.required],
      HalfDayHours: ['', Validators.required],
      exitTime: [''],
      LunchTimeApplicable: [''],
      LunchTimeFrom: [''],
      LunchTimeTo: [''],
      shortleave: [''],
      AfterWorkingHour: [''],
      shortleaveNo: [''],
      MaxOvertime: [''],
      Paidoff: [''],
      Weeklyoffdays: [''],
      weekoffdaysform1: [''],
      weekoffdaysform: [''],
      Constraint: [''],
      ConstraintIntime: [''],
      ConstraintOuttime: [''],
      Constrainthalfday: [''],
      Constraintfullday: [''],
      alternateWeeklyoffdays: ['']
    });

    this.weekoffdays = [
      { day_id: 1, day_text: '1st' },
      { day_id: 2, day_text: '2nd' },
      { day_id: 3, day_text: '3rd' },
      { day_id: 4, day_text: '4th' },
      { day_id: 5, day_text: '5th' }
    ];
    this.weekoffdaystype = [
      { day_id: 1, day_text: '1st' },
      { day_id: 2, day_text: '2nd' },
      { day_id: 3, day_text: '3rd' },
      { day_id: 4, day_text: '4th' },
      { day_id: 5, day_text: '5th' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'day_id',
      textField: 'day_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true
    };
    this.addtimeruleform = this.formBuilder.group({
      Days: [this.selectedItems]
    });
    this.LateExemption = false;
    this.LateExemptionafter = false;
    this.sortleave = false;
    this.extraworking = false;
    this.extraworkWeekoff = false;
    this.constraint = false;
    this.lunchtimefn = false;
    this.constraint = false;
    this.exitimediv = false;
  }
  get f() { return this.addtimeruleform.controls; }

  onSubmit() {
    console.log(this.acb);
    this.TimeRuleModel = {
      "createdBy": "ad5610a8-02ff-4123-bc7d-9148d9ffbd20",
      "createdDate": "2019-04-08",
      "deleted": "0",
      "fulldayMinuteForWOorH": "9",
      "halfdayMinuteForWOorH": "5",
      "inTimeForWOorH": "08:06",
      "inTimeFrom": "08:09",
      "inTimeOut": "20:09",
      "inTimeRelaxation": "20:09",
      "inTimeRelaxationDays": "2",
      "inTimeRelaxationDur": "20:09",
      "isConstAppForWOorHOvertime": "",
      "lunchInTimeFrom": "",
      "lunchOutTimeFrom": "",
      "maxOvertimeAllowedMinute": "",
      "modifiedBy": "ad5610a8-02ff-4123-bc7d-9148d9ffbd20",
      "modifiedDate": "2019-04-08",
      "noonInTimeFrom": "20:07",
      "noonInTimeRelaxation": "",
      "noonInTimeRelaxationDays": "",
      "noonInTimeRelaxationDur": "",
      "noonInTimeTo": "18:07",
      "outTimeForWOorH": "21:08",
      "overtimePaidOffOrLeave": "",
      "shortLeaveAllowedAfterMinute": "",
      "shortLeaveAllowedDays": "",
      "shortLeaveDur": "",
      "timeZoneId": "",
      "title": "riya",
      "weekDayOff": "Saturday",
      "weekDayOffId": ['1', '2', '3'],
      "alternateDayOff": "Sunday",
      "alternateDayOffId": ['0'],
      "alternateweekDayOffId": [""],
      "timeRuleId": "e8f28eda-66a8-4363-a342-458l3e47a179"
    }
    // this.adddate = this.TimeRuleModel
    // this.weekoffdaystypelist.push(this.onItemSelect);
    this.submitted = true
    // stop here if form is invalid
    if (!this.addtimeruleform.valid) {
      return false;
    } else if (this.addtimeruleform.valid) {
      debugger
      console.log(this.http.post(environment.baseUrl + '/api/Time/InsertUpdateTimeRule', ''))
      this.http.post(environment.baseUrl + '/api/Time/InsertUpdateTimeRule', this.TimeRuleModel).subscribe((res: Response) => {
        console.log(res);
        console.log("value inserted");
        //this.isAddtimerule = false;
        //this.addtimeruleform.reset();
      });

    }
    //window.location.reload();
  }
  acb = [];
  onItemSelect(item: any) {

    this.gtd = item.day_id;
    this.acb.push(this.gtd);
    console.log(this.acb)
  }


  onSelectAll(items: any) {
    console.log('onSelectAll', items);
  }
  onDeSelect(item: any) {
    debugger
    console.log('onDeSelect', item);
  }
  onDeSelectAll(items: any) {
    console.log('onDeSelectAll', items);
  }
  onFilterChange(items: any) {
    console.log('onFilterChange', items);
  }
  toogleShowFilter() {
    this.ShowFilter = !this.ShowFilter;
    this.dropdownSettings = Object.assign({}, this.dropdownSettings, { allowSearchFilter: this.ShowFilter });
  }

  handleLimitSelection() {
    if (this.limitSelection) {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: 2 });
    } else {
      this.dropdownSettings = Object.assign({}, this.dropdownSettings, { limitSelection: null });
    }
  }
  latexemradio(e: string): void {
    if (e === "yes") {
      this.LateExemption = true;
    }
    else
      this.LateExemption = false;
  }
  latexemafterradio(e: string): void {
    if (e === "yes") {
      this.LateExemptionafter = true;
    }
    else
      this.LateExemptionafter = false;
  }
  sortleaveradio(e: string): void {
    if (e === "yes") {
      this.sortleave = true;
    }
    else
      this.sortleave = false;
  }
  extraworkradio(e: string): void {
    if (e === "yes") {
      this.extraworking = true;
    }
    else
      this.extraworking = false;
  }
  extraweekoffradio(e: string): void {
    if (e === "yes") {
      this.extraworkWeekoff = true;
    }
    else {
      this.extraworkWeekoff = false;
      this.constraint = false;
    }
  }
  lunchtime(event: any) {
    if (event.target.value === 'yes') {
      this.lunchtimefn = true;
    }
    else
      this.lunchtimefn = false;
    // this.selectedtype = event.target.value;
    // var a = this.selectedtype;
  }
  constraintselect(event: any) {
    if (event.target.value == 'Constraint') {
      this.constraint = true;
    }
    else
      this.constraint = false;
  }
  exitimeradio(e: string): void {
    if (e === 'yes') {
      this.exitimediv = true;
    }
    else
      this.exitimediv = false;
  }
  // week off days
  weekoffdays_fn(event) {
    this.weekoffdaysSelect = event.target.value;
    console.log(this.weekoffdaysSelect);
  }
  getTimeRule(timeid) {
    this.timeid = localStorage.getItem('timeRuleId');
    this.http.get(environment.baseUrl + '/api/Time/GetTimeRuleByIdtimeRuleId=' + 'e8f28eda-66a8-4363-a238-5b4184d7a179').subscribe(result => {
      debugger
      this.timerulebyid = result;
      console.log(this.timerulebyid);
    }, error => console.error(error));
  }
}
