import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationcompComponent } from './validationcomp.component';

describe('ValidationcompComponent', () => {
  let component: ValidationcompComponent;
  let fixture: ComponentFixture<ValidationcompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidationcompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidationcompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
