import { Component, OnInit, ViewChild } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { MatPaginator, MatTableDataSource, MatSort, MatSelectModule } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AddemployeeComponent } from '../addemployee/addemployee.component';

declare function datetimeFunc(): any;
declare function select2Func(): any;
// import { ContextMenuComponent } from 'ngx-contextmenu';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})

export class EmployeeComponent implements OnInit {


  isCardView: boolean;
  isGridView: boolean;
  isSelected: boolean;
  display = 'none';
  authtoken: void;
  uname: string;
  passw: string;
  employeelist: any;
  tokenData: any;
  loginHeaders: { headers: HttpHeaders; };
  usercredential: { 'UserName': string; 'Password': string; };
  selectfilter: any;
  slelectfilterA: any;
  selectType: any;
  selectTypeA: any;
  filterType: any;
  filterTypeA: any;
  employeeid: any;

  length: any;

  userFilter: any = { EmployeeName: '' };
  selectedStatus: any;

  officialEmailId = new FormControl('');


  //columnsToDisplay: string[] = this.displayedColumns.slice();
  displayedColumns: any[];
  dataSource = new MatTableDataSource([]);
  selection = new SelectionModel;
  basicinfo_form: any;
  deletemodal: any;
  deleteval: string;
  biometricsiDs: any;
  emp: Object;
  Datelogs: string;
  biometriIds: any;
  biometriId: void;
  filterlevel: string;
  selectstatus: any;
  selectsta: any;
  count: any;

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(AddemployeeComponent) child: AddemployeeComponent;

  showMessage(message: any) {
  }
  constructor(private http: HttpClient, private router: Router, public SharingService: SharingService, public _formBuilder: FormBuilder, @Inject(DOCUMENT) document) {

  }
  ngAfterViewInit() {
    select2Func();
    datetimeFunc();
  }
  ngOnInit() {
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.isSelected = true;
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.isCardView = true;
    this.isGridView = false;
    this.uname = localStorage.getItem('currentUser');
    this.passw = localStorage.getItem('currentPassword');
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeListForView?EmployeeStatus=active&DesignationId=&DepartmentId=&EmployeeType')
      .subscribe(result => {
        this.displayedColumns = Object.keys(result['0'])
        this.employeelist = result;
        this.count = this.employeelist.length

        this.dataSource = new MatTableDataSource(this.employeelist);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }, error => console.error(error));
    this.http.get(environment.baseUrl + '/api/Master/GetEmployeeStatusList').subscribe(result => {
      this.emp = result;
    }, error => console.error(error));
  }


  Onboarding() {
    document.getElementById('onboard').innerText = "Onboarding";
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  applyGlobal(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  editemp(editbioid) {
    document.getElementById('onboard').innerText = "Edit Employee";
    this.child.GeteditemployeeForm(editbioid);

    //this.child.GeteditleaveRuleForm(leaveRuleId);
  }

  filterTypefn(event) {
    this.filterType = event.target.value;
    if (this.filterType == '1') {
      this.isSelected = true;
    }
    if (this.filterType == '2') {
      this.isSelected = false;
      this.http.get(environment.baseUrl + '/api/Master/GetDepartmentList').subscribe(result => {
        this.filterTypeA = result;
      }, error => console.error(error));
    }
    else if (this.filterType == '3') {
      this.isSelected = false;
      this.http.get(environment.baseUrl + '/api/Master/GetDesignationList').subscribe(result => {
        this.filterTypeA = result;
      }, error => console.error(error));
    }
    else if (this.filterType == '4') {
      this.isSelected = false;
      this.http.get(environment.baseUrl + '/api/Master/GetEmployeeStatusList').subscribe(result => {
        this.filterTypeA = result;
      }, error => console.error(error));
    }

    else if (this.filterType == '5') {
      this.isSelected = false;
      this.http.get(environment.baseUrl + '/api/Master/GetEmploymentTypeList').subscribe(result => {
        this.filterTypeA = result;
      }, error => console.error(error));
    }
  }

  selectTypefn(event) {
    this.filterlevel = 'status'
    this.selectstatus = event.target.value;
    console.log(this.selectstatus);
    this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeListForView?EmployeeStatus=' + this.selectstatus + '&DesignationId=&DepartmentId=&EmployeeType=').subscribe(result => {
      this.employeelist = result;
      this.count = this.employeelist.length
      this.selectsta = this.selectstatus
    }, error => console.error(error));
  }

  selectTypefndepartment(event) {
    this.filterlevel = 'department'
    this.selectType = event.target.value;
  }

  selectTypefndesignation(event) {
    this.filterlevel = 'designation';
    this.selectType = event.target.value;
  }

  selectTypefnemptype(event) {
    this.filterlevel = 'type';
    this.selectType = event.target.value;
  }

  searcbttn(empstatus, filterlvl, seltyps) {
    console.log(filterlvl);
    console.log(seltyps);
    if (filterlvl == undefined) {
      alert('please select any filter type');
    }
    if (seltyps == undefined) {
      alert('please select any filter level value');
    }
    else {
      if (filterlvl == 'type') {
        if (this.selectstatus == undefined) {
          this.selectstatus = 'active';
        }
        else {
          this.selectstatus;
        }
        this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeListForView?EmployeeStatus=' + this.selectstatus + '&DesignationId=&DepartmentId=&EmployeeType=' + seltyps).subscribe(result => {
          this.employeelist = result;
          this.count = this.employeelist.length
        }, error => console.error(error));
      }
      else if (filterlvl == 'designation') {

        if (this.selectstatus == undefined) {
          this.selectstatus = 'active';
        }
        else {
          this.selectstatus;
        }
        this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeListForView?EmployeeStatus=' + this.selectstatus + '&DesignationId=' + seltyps + '&DepartmentId=&EmployeeType=').subscribe(result => {
          this.employeelist = result;
          this.count = this.employeelist.length
        }, error => console.error(error));
      }
      else if (filterlvl == 'department') {
        if (this.selectstatus == undefined) {
          this.selectstatus = 'active';
        }
        else {
          this.selectstatus;
        }
        this.http.get(environment.baseUrl + '/api/EIM/GetEmployeeListForView?EmployeeStatus=' + this.selectstatus + '&DesignationId=&DepartmentId=' + seltyps + '&EmployeeType=').subscribe(result => {
          this.employeelist = result;
          this.count = this.employeelist.length
        }, error => console.error(error));
      }
    }


  }

  empProfile(empbiometric) {
    localStorage.setItem('empbiometric', empbiometric);
    this.router.navigate(['employee-profile']);
  }

  bioId(biometrics) {
    this.biometricsiDs = biometrics;
  }
  // delete employee
  delete_emp(delIds) {
    this.deletemodal = {
      "deleted": "1",
      "biometricId": delIds,
      "modifiedBy": "A58D9EF0-D10F-4326-B12A-2142E53E0128",
      "modifiedDate": this.Datelogs
    }

    this.http.put(environment.baseUrl + '/api/EIM/DeleteEmployeeByBiometricId', this.deletemodal).subscribe((res: Response) => {
      console.log(res);
    }, error => console.error(error));
    window.location.reload();
  }
  gridview() {
    this.isGridView = true;
    this.isCardView = false;
  }
  cardview() {
    this.isCardView = true;
    this.isGridView = false;
  }
}