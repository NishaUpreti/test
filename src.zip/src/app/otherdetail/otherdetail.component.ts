import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { SharingService } from '../sharing.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { OtherdetailModule } from "../../app/model/otherdetail/otherdetail.module";
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-otherdetail',     
  templateUrl: './otherdetail.component.html',
  styleUrls: ['./otherdetail.component.css']
})
export class OtherdetailComponent implements OnInit {      

  otherdetail_form: FormGroup;
  otherdetailmodel: any;
  Date: any;
  Datelogs: any;
  uname: any;
  target: object;
  fromdate: object;
  todate: object;
  billableRevenue: object;
  bdTarget: object;
  planId: object;
  billableRevenueincentive:object;
  bdTargetincentive:object;

  fromDateincentive: object;
  toDateincentive: object;
  submitted = false;
  otherdetailmodeltarget: {"biometricId": string; "target": any; "fromdate": any; "todate": any; "revisedStatus": string; "targetOnBillable": any; "targetOnBD": string; "createdDate": any; "modifiedDate": any; "createdBy": any; "modifiedBy": any; "deleted": string; };
  otherdetailmodelincentive: { "biometricId": string; "planId": string; "fromdate": any; "todate": any; "billableRevenue": string; "bdTarget": any; "durationCompleted": string; "createdDate": any; "modifiedDate": any; "createdBy": any; "modifiedBy": any; "deleted": string; };
  OtherDetailtargetincentive:{}
  biometrics: string;
  constructor(private http: HttpClient, public formBuilder: FormBuilder, public SharingService: SharingService) {
  }

  ngOnInit() {
    this.otherdetail_form = this.formBuilder.group({
      target: ['', Validators.required],
      fromdate: ['', Validators.required],
      todate: ['', Validators.required],
      billableRevenue: ['', Validators.required],
      bdTarget: ['', Validators.required],
      planId: ['', Validators.required],
      fromDateincentive: ['', Validators.required],
      toDateincentive: ['', Validators.required]
    });
    this.uname = localStorage.getItem('currentUser');
    console.log(this.uname);
    this.Date = formatDate(new Date(), 'yyyy-MM-dd', 'en');
    this.Datelogs = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  }
  get f() { return this.otherdetail_form.controls; }

  onSubmit() {
    this.biometrics= localStorage.getItem('biometrics');

    this.otherdetailmodeltarget = {
      "biometricId": this.biometrics,
      "target": this.otherdetail_form.value.target,
      "fromdate": this.otherdetail_form.value.fromdate,
      "todate": this.otherdetail_form.value.todate,
      "revisedStatus":'',
      "targetOnBillable": this.otherdetail_form.value.billableRevenue,
      "targetOnBD":this.otherdetail_form.value.bdTarget,
      "createdDate": this.Datelogs,
      "modifiedDate": this.Datelogs,
      "createdBy": "",
      "modifiedBy": "",
      "deleted": "0"
    }

    this.otherdetailmodelincentive = {
      "biometricId": this.biometrics,
      "planId":  this.otherdetail_form.value.planId,
      "fromdate": this.otherdetail_form.value.fromDateincentive,
      "todate": this.otherdetail_form.value.toDateincentive,
      "billableRevenue":this.otherdetail_form.value.billableRevenueincentive,
      "bdTarget": this.otherdetail_form.value.bdTargetincentive,
      "durationCompleted":"",
      "createdDate": this.Datelogs,
      "modifiedDate": this.Datelogs,
      "createdBy": "",
      "modifiedBy": "",
      "deleted": "0"
    }

    this.OtherDetailtargetincentive = {
      "personal":{},
      "employement":[],
      "qualification":[],
      "target":this.otherdetailmodeltarget,
      "incentive":this.otherdetailmodelincentive,
      "payroll":{},
      "document":[]
    }

    this.submitted = true;
 
    // stop here if form is invalid
    if (this.otherdetail_form.invalid) {
      return;
    }
    else if (!this.otherdetail_form.invalid) {
      this.http.post(environment.baseUrl + '/api/EIM/InsertUpdateEmployeeOtherInfo', this.OtherDetailtargetincentive).subscribe((res: Response) => {
        console.log(res);
      })
    }

    }
    
  }

