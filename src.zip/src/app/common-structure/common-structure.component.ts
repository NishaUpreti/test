import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-structure',
  templateUrl: './common-structure.component.html',
  styleUrls: ['./common-structure.component.css']
})
export class CommonStructureComponent implements OnInit {
  screen: any;

  constructor() { }

  ngOnInit() {

	
  }

}
