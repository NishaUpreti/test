import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  uname: string;

  constructor() { }

  ngOnInit() {


    this.uname = localStorage.getItem('currentUser');
    console.log(this.uname)
  }

  }