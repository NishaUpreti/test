import { Component, OnInit, EventEmitter, Output  } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { LeaveEntitlementModel } from '../model/leave-entitlement-model';
import {formatDate} from '@angular/common';
declare function datetimeFunc(): any ;
declare function select2Func(): any ;

@Component({
  selector: 'app-add-entitlement',
  templateUrl: './add-entitlement.component.html',
  styleUrls: ['./add-entitlement.component.css']
})
export class AddEntitlementComponent implements OnInit {

  @Output() getLeaveEntitled = new EventEmitter<string>();
  getLeaveRuleEvent: any;
  addLeaveEntitlementForm: FormGroup;
  todayDate: string;
  
  callParent(): void {
    this.getLeaveRuleEvent.next();
  }

  constructor(private http: HttpClient, public formBuilder: FormBuilder) { }

  ngOnInit() {

    
    this.addLeaveEntitlementForm = this.formBuilder.group({
      newLeaveType:['', Validators.required],
      descriptionNew:['', Validators.required]
    });
    this.todayDate = formatDate(new Date(), 'yyyy/MM/dd', 'en');
   
  }
  
  ngAfterViewInit() {
    select2Func();
    datetimeFunc();
  }

}
