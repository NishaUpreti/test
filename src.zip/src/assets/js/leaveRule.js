$(document).ready(function ()
    {
        $('.tableFilter .dropdown-toggle').click(function (){
            dropDownFixPosition($(this),$('.dropdown-menu'));
        });
        function dropDownFixPosition(button,dropdown){
            var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', (dropDownTop) + "px");
                dropdown.css('left', (button.offset().left) + "px");
        }
    }
)