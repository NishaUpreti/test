$(document).ready(function (){

// Select2
	
if($('.select').length > 0 ){
    $('.select').select2({
        // minimumResultsForSearch: -1,
        width: '100%'
    });
}
// Date Time Picker
	
if($('.datetimepicker').length > 0 ){
    $('.datetimepicker').datetimepicker({
        format: 'YYYY-MM-DD'
    });
}

        $('.tableFilter .dropdown-toggle').click(function (){
            dropDownFixPosition($(this),$('.dropdownContext'));
        });
        
        function dropDownFixPosition(button,dropdown){
            debugger;
            var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', (dropDownTop) + "px");
                dropdown.css('left', (button.offset().left) + "px");
        }
    }
)