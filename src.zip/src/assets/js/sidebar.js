// Sidebar

! function($) {
    "use strict";
    var Sidemenu = function() {
        this.$menuItem = $("#sidebar-menu a");
    };

	Sidemenu.prototype.init = function() {
		var $this = this;
		$this.$menuItem.on('click', function(e) {
		if ($(this).parent().hasClass("submenu")) {
			e.preventDefault();
		}
		if (!$(this).hasClass("subdrop")) {
			$("ul", $(this).parents("ul:first")).slideUp(350);
			$("a", $(this).parents("ul:first")).removeClass("subdrop");
			$(this).next("ul").slideDown(350);
			$(this).addClass("subdrop");
		} else if ($(this).hasClass("subdrop")) {
			$(this).removeClass("subdrop");
			$(this).next("ul").slideUp(350);
		}

		$('.modal-backdrop').remove(); //(nivi)added according to requirement.
	});
		$("#sidebar-menu ul li.submenu a.active").parents("li:last").children("a:first").addClass("active").trigger("click");
	},
	$.Sidemenu = new Sidemenu;

}(window.jQuery),

$(document).ready(function() {

// Sidebar overlay

var $sidebarOverlay = $(".sidebar-overlay");
$("#mobile_btn, .task-chat").on("click", function(e) {
    var $target = $($(this).attr("href"));
    if ($target.length) {
        $target.toggleClass("opened");
        $sidebarOverlay.toggleClass("opened");
        $("html").toggleClass("menu-opened");
        $sidebarOverlay.attr("data-reff", $(this).attr("href"));
    }
    e.preventDefault();
});

$sidebarOverlay.on("click", function(e) {
    var $target = $($(this).attr("data-reff"));
    if ($target.length) {
        $target.removeClass("opened");
        $("html").removeClass("menu-opened");
        $(this).removeClass("opened");
        $(".main-wrapper").removeClass("slide-nav-toggle");
    }
    e.preventDefault();
});

// Sidebar Initiate

$.Sidemenu.init();

// Sidebar Slimscroll

if($('.slimscroll').length > 0 ){
    $('.slimscroll').slimScroll({
        height: '100%',
        width: '100%',
        position: 'right',
        size: "7px",
        color: '#ccc',
        wheelStep: 10,
        touchScrollStep : 100
    });
    var h=$(window).height()-60;
    $('.slimscroll').height(h);
    $('.sidebar .slimScrollDiv').height(h);
    
    $(window).resize(function(){
        var h=$(window).height()-60;
        $('.slimscroll').height(h);
        $('.sidebar .slimScrollDiv').height(h);
    });
}



// Mobile Menu

if($('.main-wrapper').length > 0 ){
	var $wrapper = $(".main-wrapper");
		$(document).on('click', '#mobile_btn', function (e) {
			$(".dropdown.open > .dropdown-toggle").dropdown("toggle");
			return false;
		});
		$(document).on('click', '#mobile_btn', function (e) {
			$wrapper.toggleClass('slide-nav-toggle');
			$('#chat_sidebar').removeClass('opened');
			return false;
		});
		$(document).on('click', '#open_msg_box', function (e) {
			$wrapper.toggleClass('open-msg-box').removeClass('');
			$('.dropdown').removeClass('open');
			return false;
		});
	}

    // Small Sidebar
	
	if (screen.width >= 992) {
		// $('#toggle_btn').on('click', function() {
		// 	if($('body').hasClass('mini-sidebar')) {
		// 		$('body').removeClass('mini-sidebar');
		// 		$('.subdrop + ul').slideDown();
		// 	} else {
		// 		$('body').addClass('mini-sidebar');
		// 		$('.subdrop + ul').slideUp();
		// 	}
		// 	return false;
		// });	
		
		$(document).on('mouseover', function(e){
			e.stopPropagation();
			if($('#miniSide').hasClass('mini-sidebar') && $('#toggle_btn').is(':visible')) {
				var targ = $(e.target).closest('.sidebar').length;
				if(targ) {
					$('#miniSide').addClass('expand-menu');
					$('.subdrop + ul').slideDown();
				} else {
					$('#miniSide').removeClass('expand-menu');
					$('.subdrop + ul').slideUp();
				}
			}
		});
	}


});