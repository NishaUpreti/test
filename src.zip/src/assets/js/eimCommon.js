
     // Select2
     function select2Func(){
        if($('.select').length > 0 ){
            $('.select').select2({
                // minimumResultsForSearch: -1,
                width: '100%'
            });
        }
     }
    

    // Date Time Picker
    function datetimeFunc(){  
        if($('.datetimepicker').length > 0 ){
            $('.datetimepicker').datetimepicker({
                format: 'YYYY-MM-DD'
            });
        }
    }

    function datetimeBothFunc(){    
        if($('.datetimeBothpicker').length > 0 ){
            $('.datetimeBothpicker').datetimepicker();
        }
    }
    function onlyTimeFunc(){    
        if($('.timeOnly').length > 0 ){
            $('.timeOnly').datetimepicker({
                format: 'LT'
            });
        }
    }

