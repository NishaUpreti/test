$(document).ready(function() {
// Message Notification Slimscroll

if($('.msg-list-scroll').length > 0 ){
    $('.msg-list-scroll').slimscroll({
        height:'100%',
        color: '#878787',
        disableFadeOut : true,
        borderRadius:0,
        size:'4px',
        alwaysVisible:false,
        touchScrollStep : 100
    });
    var h=$(window).height()-124;
    $('.msg-list-scroll').height(h);
    $('.msg-sidebar .slimScrollDiv').height(h);  
    
    $(window).resize(function(){
        var h=$(window).height()-124;
        $('.msg-list-scroll').height(h);
        $('.msg-sidebar .slimScrollDiv').height(h);
    });
}
});
