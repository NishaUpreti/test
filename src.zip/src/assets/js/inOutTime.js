$(document).ready(function ()
    {

        // Select2
	
        if($('.select').length > 0 ){
            $('.select').select2({
                // minimumResultsForSearch: -1,
                width: '100%'
            });
        }
        // Date Time Picker
            
        if($('.datetimepicker').length > 0 ){
            $('.datetimepicker').datetimepicker({
                format: 'DD/MM/YYYY'
            });
        }


        $('#InOutTime').DataTable({
            "scrollX": true,
            "scrollY": "50vh",
            "scrollCollapse": true,
            "bSortCellsTop": true,
            deferRender: true,
            colReorder: true,
            fixedColumns: {
                leftColumns: 2
            }
    
        });

        $('.tableFilter .dropdown-toggle').click(function (){
            dropDownFixPosition($(this),$('.dropdownContext'));
        });
        function dropDownFixPosition(button,dropdown){
            var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', (dropDownTop) + "px");
                dropdown.css('left', (button.offset().left) + "px");
        }

        $('.tableFilterPopup .dropdown-toggle').click(function (){
            dropDownFixPosition($(this),$('.dropdownContext'));
        });
        function dropDownFixPosition(button,dropdown){
            var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', (dropDownTop - 70) + "px");
                dropdown.css('left', (button.offset().left - 40) + "px");
        }
    }
)