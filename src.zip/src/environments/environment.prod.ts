export const environment = {
  production: true,
  baseUrl: 'https://hitechlab.globalhuntindia.com:60017',
};
